// KisanMithr Dynamic UI Components
import { LocalDB, GeminiService, WeatherService, DiseaseService } from './services.js';
import { CROPS_DB, SCHEMES_DB, LANGUAGES } from './data.js';

export const Components = {
  // ==========================================
  // 1. AUTHENTICATION MODULE
  // ==========================================
  Auth: {
    render() {
      return `
        <div class="min-h-[85vh] flex items-center justify-center bg-grid-pattern py-8 px-4">
          <div class="glass-card w-full max-w-md p-8 rounded-3xl border border-white/60 relative overflow-hidden transition-all duration-300">
            <!-- Decorative blur shapes -->
            <div class="absolute -top-12 -left-12 w-32 h-32 bg-green-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
            <div class="absolute -bottom-12 -right-12 w-32 h-32 bg-emerald-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
            
            <div class="relative z-10 text-center mb-8">
              <div class="inline-flex items-center justify-center p-3 bg-green-500/10 text-green-600 rounded-2xl mb-3">
                <i data-lucide="sprout" class="w-8 h-8"></i>
              </div>
              <h2 class="text-3xl font-extrabold text-gray-900 tracking-tight">Welcome to KisanMithr</h2>
              <p class="text-gray-500 mt-2 text-sm">Empowering Agriculture Through Intelligence</p>
            </div>

            <!-- Tabs for Login / Register -->
            <div class="flex p-1 bg-green-900/5 rounded-xl mb-6 relative">
              <button id="tab-login" class="flex-1 py-2 text-sm font-semibold rounded-lg bg-white text-green-700 shadow-sm transition-all duration-200">Login</button>
              <button id="tab-register" class="flex-1 py-2 text-sm font-semibold rounded-lg text-gray-600 hover:text-green-700 transition-all duration-200">Register</button>
            </div>

            <!-- Role Selection -->
            <div class="mb-6">
              <label class="block text-xs font-semibold uppercase tracking-wider text-gray-400 mb-2">Select Your Role</label>
              <div class="grid grid-cols-2 gap-3">
                <label class="role-card cursor-pointer flex flex-col items-center justify-center p-4 rounded-2xl border-2 border-green-500 bg-green-50/40 text-green-800 transition-all">
                  <input type="radio" name="auth-role" value="farmer" checked class="sr-only">
                  <i data-lucide="tractor" class="w-7 h-7 mb-2"></i>
                  <span class="text-sm font-bold">Farmer</span>
                  <span class="text-[10px] text-green-600/80">Sell crops & get tips</span>
                </label>
                <label class="role-card cursor-pointer flex flex-col items-center justify-center p-4 rounded-2xl border-2 border-gray-100 hover:border-green-200 bg-white text-gray-600 transition-all">
                  <input type="radio" name="auth-role" value="customer" class="sr-only">
                  <i data-lucide="shopping-bag" class="w-7 h-7 mb-2"></i>
                  <span class="text-sm font-bold">Customer</span>
                  <span class="text-[10px] text-gray-400">Buy fresh farm foods</span>
                </label>
              </div>
            </div>

            <!-- Login Form -->
            <form id="form-login" class="space-y-4">
              <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Mobile Number / Email</label>
                <div class="relative">
                  <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                    <i data-lucide="phone" class="w-4 h-4"></i>
                  </span>
                  <input type="text" id="login-id" required placeholder="e.g. 9876543210" class="block w-full pl-10 pr-3 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500/20 focus:border-green-500 focus:outline-none bg-white/50 text-sm">
                </div>
              </div>
              <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Verify with OTP</label>
                <div class="flex gap-2">
                  <input type="text" id="login-otp" placeholder="Enter 4-digit OTP" class="block w-full px-3 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500/20 focus:border-green-500 focus:outline-none bg-white/50 text-sm">
                  <button type="button" id="btn-send-otp" class="px-4 py-2 bg-green-50 hover:bg-green-100 text-green-700 font-semibold text-xs rounded-xl border border-green-200 transition-all flex items-center justify-center shrink-0">Send OTP</button>
                </div>
              </div>
              <button type="submit" class="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold rounded-xl shadow-lg shadow-green-600/10 transition-all flex items-center justify-center gap-2 mt-6">
                <span>Access Dashboard</span>
                <i data-lucide="arrow-right" class="w-4 h-4"></i>
              </button>
              <div class="text-center mt-4">
                <span class="text-xs text-gray-400">Demo accounts: Use 9876543210 (Farmer) or 8765432109 (Customer). OTP is 1234.</span>
              </div>
            </form>

            <!-- Register Form (Hidden initially) -->
            <form id="form-register" class="space-y-4 hidden">
              <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Full Name</label>
                <input type="text" id="reg-name" required placeholder="Enter full name" class="block w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500/20 focus:border-green-500 focus:outline-none bg-white/50 text-sm">
              </div>
              <div class="grid grid-cols-2 gap-2">
                <div>
                  <label class="block text-xs font-semibold text-gray-500 mb-1">Mobile Number</label>
                  <input type="tel" id="reg-phone" required placeholder="10-digit mobile" class="block w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500/20 focus:border-green-500 focus:outline-none bg-white/50 text-sm">
                </div>
                <div>
                  <label class="block text-xs font-semibold text-gray-500 mb-1">Email (Optional)</label>
                  <input type="email" id="reg-email" placeholder="email@gmail.com" class="block w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500/20 focus:border-green-500 focus:outline-none bg-white/50 text-sm">
                </div>
              </div>

              <!-- Farmer Specific Fields -->
              <div id="farmer-fields" class="space-y-3 pt-2 border-t border-gray-100">
                <p class="text-xs font-bold text-green-700">Farm & GPS Details</p>
                <div class="grid grid-cols-2 gap-2">
                  <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1">Soil Type</label>
                    <select id="reg-soil" class="block w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500/20 focus:outline-none bg-white text-sm">
                      <option value="Black Soil">Black Soil</option>
                      <option value="Loamy">Loamy</option>
                      <option value="Clayey">Clayey</option>
                      <option value="Sandy Loam">Sandy Loam</option>
                    </select>
                  </div>
                  <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1">Land Area (Acres)</label>
                    <input type="number" step="0.1" id="reg-land" placeholder="e.g. 5" class="block w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500/20 focus:outline-none bg-white/50 text-sm">
                  </div>
                </div>
                <div class="grid grid-cols-2 gap-2">
                  <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1">Aadhaar Number</label>
                    <input type="text" id="reg-aadhaar" placeholder="12-digit number" class="block w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500/20 focus:outline-none bg-white/50 text-sm">
                  </div>
                  <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1">Budget (INR)</label>
                    <input type="number" id="reg-budget" placeholder="e.g. 50000" class="block w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500/20 focus:outline-none bg-white/50 text-sm">
                  </div>
                </div>
                <div class="grid grid-cols-3 gap-2">
                  <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1">Village</label>
                    <input type="text" id="reg-village" placeholder="Village" class="block w-full px-2 py-1.5 border border-gray-200 rounded-xl text-xs">
                  </div>
                  <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1">District</label>
                    <input type="text" id="reg-district" placeholder="District" class="block w-full px-2 py-1.5 border border-gray-200 rounded-xl text-xs">
                  </div>
                  <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1">PIN Code</label>
                    <input type="text" id="reg-pin" placeholder="PIN" class="block w-full px-2 py-1.5 border border-gray-200 rounded-xl text-xs">
                  </div>
                </div>
                <div>
                  <button type="button" id="btn-gps" class="w-full py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5">
                    <i data-lucide="map-pin" class="w-3.5 h-3.5 animate-bounce"></i>
                    <span id="gps-status">Get GPS Farm Location</span>
                  </button>
                  <input type="hidden" id="reg-gps-val" value="">
                </div>
              </div>

              <button type="submit" class="w-full py-3 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2">
                <span>Create Account</span>
                <i data-lucide="user-plus" class="w-4 h-4"></i>
              </button>
            </form>
          </div>
        </div>
      `;
    },

    init(appState, navigateTo) {
      const loginTab = document.getElementById('tab-login');
      const registerTab = document.getElementById('tab-register');
      const loginForm = document.getElementById('form-login');
      const registerForm = document.getElementById('form-register');
      const roleInputs = document.getElementsByName('auth-role');
      const roleCards = document.querySelectorAll('.role-card');
      const farmerFields = document.getElementById('farmer-fields');
      const gpsBtn = document.getElementById('btn-gps');
      const gpsStatus = document.getElementById('gps-status');
      const gpsVal = document.getElementById('reg-gps-val');
      const sendOtpBtn = document.getElementById('btn-send-otp');

      // Tab switching
      loginTab.addEventListener('click', () => {
        loginTab.className = "flex-1 py-2 text-sm font-semibold rounded-lg bg-white text-green-700 shadow-sm transition-all";
        registerTab.className = "flex-1 py-2 text-sm font-semibold rounded-lg text-gray-600 hover:text-green-700 transition-all";
        loginForm.classList.remove('hidden');
        registerForm.classList.add('hidden');
      });

      registerTab.addEventListener('click', () => {
        registerTab.className = "flex-1 py-2 text-sm font-semibold rounded-lg bg-white text-green-700 shadow-sm transition-all";
        loginTab.className = "flex-1 py-2 text-sm font-semibold rounded-lg text-gray-600 hover:text-green-700 transition-all";
        registerForm.classList.remove('hidden');
        loginForm.classList.add('hidden');
      });

      // Role card selection visuals
      roleInputs.forEach(input => {
        input.addEventListener('change', (e) => {
          const selectedRole = e.target.value;
          roleCards.forEach(card => {
            card.className = "role-card cursor-pointer flex flex-col items-center justify-center p-4 rounded-2xl border-2 border-gray-100 bg-white text-gray-600 transition-all";
          });
          
          const parent = e.target.closest('.role-card');
          parent.className = "role-card cursor-pointer flex flex-col items-center justify-center p-4 rounded-2xl border-2 border-green-500 bg-green-50/40 text-green-800 transition-all";
          
          if (selectedRole === 'farmer') {
            farmerFields.classList.remove('hidden');
          } else {
            farmerFields.classList.add('hidden');
          }
        });
      });

      // OTP Mock triggers
      sendOtpBtn.addEventListener('click', () => {
        const phone = document.getElementById('login-id').value;
        if (!phone) {
          window.app.showToast("Please enter your phone number first!", "error");
          return;
        }
        window.app.showToast("Demo OTP '1234' sent successfully!", "success");
        document.getElementById('login-otp').value = "1234";
      });

      // GPS simulation
      gpsBtn.addEventListener('click', () => {
        gpsStatus.innerText = "Accessing GPS...";
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            const val = `${pos.coords.latitude.toFixed(4)}° N, ${pos.coords.longitude.toFixed(4)}° E`;
            gpsVal.value = val;
            gpsStatus.innerText = `GPS Located: ${val}`;
            window.app.showToast("Farm coordinates captured!", "success");
          },
          (err) => {
            // Mock random GPS in Anantapur, AP if permission denied or offline
            const val = `14.${(6000 + Math.random()*200).toFixed(0)}° N, 77.${(6000 + Math.random()*200).toFixed(0)}° E`;
            gpsVal.value = val;
            gpsStatus.innerText = `GPS Simulated: ${val}`;
            window.app.showToast("Simulated GPS location stored!", "success");
          }
        );
      });

      // Handle Login Submit
      loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const contact = document.getElementById('login-id').value.trim();
        const otp = document.getElementById('login-otp').value.trim();
        const selectedRole = document.querySelector('input[name="auth-role"]:checked').value;

        if (otp !== '1234') {
          window.app.showToast("Invalid OTP. Enter '1234' for demo login.", "error");
          return;
        }

        const user = LocalDB.loginUser(contact, selectedRole);
        if (user) {
          appState.user = user;
          window.app.showToast(`Logged in as ${user.name}!`, "success");
          navigateTo(user.role === 'farmer' ? 'farmer-dashboard' : (user.role === 'admin' ? 'admin' : 'customer-dashboard'));
        } else {
          window.app.showToast("No account found with these credentials. Please Register first.", "error");
        }
      });

      // Handle Registration Submit
      registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const role = document.querySelector('input[name="auth-role"]:checked').value;
        const name = document.getElementById('reg-name').value.trim();
        const phone = document.getElementById('reg-phone').value.trim();
        const email = document.getElementById('reg-email').value.trim();

        let registrationDetails = { name, phone, email, role };

        if (role === 'farmer') {
          const soilType = document.getElementById('reg-soil').value;
          const landArea = document.getElementById('reg-land').value;
          const budget = document.getElementById('reg-budget').value;
          const aadhaarNumber = document.getElementById('reg-aadhaar').value;
          const village = document.getElementById('reg-village').value || "Mithrapur";
          const district = document.getElementById('reg-district').value || "Anantapur";
          const pinCode = document.getElementById('reg-pin').value || "515001";
          const farmLocation = gpsVal.value || "14.6819° N, 77.6006° E";

          registrationDetails = {
            ...registrationDetails,
            soilType, landArea, budget, aadhaarNumber,
            village, district, pinCode, farmLocation,
            currentCrop: "", photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=60"
          };
        } else {
          registrationDetails = {
            ...registrationDetails,
            address: "123 Green Avenue, Bengaluru, Karnataka",
            photo: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&auto=format&fit=crop&q=60"
          };
        }

        const user = LocalDB.registerUser(registrationDetails);
        appState.user = user;
        window.app.showToast("Account created successfully!", "success");
        navigateTo(user.role === 'farmer' ? 'farmer-dashboard' : 'customer-dashboard');
      });
    }
  },

  // ==========================================
  // 2. FARMER DASHBOARD MODULE
  // ==========================================
  FarmerDashboard: {
    render(appState) {
      const user = appState.user;
      const weather = WeatherService.getWeather(user.farmLocation || "Anantapur");
      
      // Calculate financial overview from expenses
      const expenses = LocalDB.getExpenses(user.id);
      const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
      
      const currentCrop = CROPS_DB.find(c => c.id === user.currentCrop) || null;
      
      return `
        <div class="space-y-6 page-fade-in">
          <!-- Welcome Bar -->
          <div class="glass-card p-6 rounded-3xl border border-white/60 flex flex-col md:flex-row items-center justify-between gap-4">
            <div class="flex items-center gap-4">
              <img src="${user.photo || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=150'}" class="w-16 h-16 rounded-2xl object-cover border-2 border-green-500 shadow-md">
              <div>
                <h2 class="text-2xl font-bold text-gray-900">Namaste, ${user.name}!</h2>
                <p class="text-sm text-gray-500 flex items-center gap-1.5 mt-0.5">
                  <i data-lucide="map-pin" class="w-4 h-4 text-green-600"></i>
                  ${user.village || 'Anantapur'}, ${user.district || 'AP'} | Farm GPS: <span class="font-mono text-xs">${user.farmLocation || 'Captured'}</span>
                </p>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <span class="px-4 py-1.5 bg-green-500/10 text-green-700 rounded-xl text-xs font-bold border border-green-200/40">Farmer Active</span>
              <button id="btn-edit-farm" class="p-2.5 hover:bg-gray-100 rounded-xl text-gray-500 hover:text-gray-700 transition" title="Settings">
                <i data-lucide="settings" class="w-5 h-5"></i>
              </button>
            </div>
          </div>

          <!-- Weather and Crop Grid -->
          <div class="grid grid-cols-1 md:grid-cols-12 gap-6">
            <!-- Weather Card -->
            <div class="md:col-span-5 glass-card p-6 rounded-3xl relative overflow-hidden flex flex-col justify-between">
              <div class="absolute right-3 top-3 opacity-10 text-green-900">
                <i data-lucide="cloud-sun-rain" class="w-36 h-36"></i>
              </div>
              <div class="relative z-10">
                <div class="flex justify-between items-start">
                  <div>
                    <p class="text-xs font-bold uppercase tracking-wider text-gray-400">Current Weather</p>
                    <h3 class="text-3xl font-extrabold text-gray-900 mt-1">${weather.temp}°C</h3>
                  </div>
                  <span class="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs font-bold">Rain Forecast: ${weather.rainProbability}</span>
                </div>
                
                <div class="grid grid-cols-2 gap-4 mt-6">
                  <div class="flex items-center gap-2">
                    <div class="p-2 bg-blue-50 text-blue-600 rounded-lg"><i data-lucide="droplet" class="w-4 h-4"></i></div>
                    <div>
                      <p class="text-[10px] text-gray-400 font-bold">HUMIDITY</p>
                      <p class="text-sm font-extrabold text-gray-700">${weather.humidity}%</p>
                    </div>
                  </div>
                  <div class="flex items-center gap-2">
                    <div class="p-2 bg-emerald-50 text-emerald-600 rounded-lg"><i data-lucide="wind" class="w-4 h-4"></i></div>
                    <div>
                      <p class="text-[10px] text-gray-400 font-bold">WIND</p>
                      <p class="text-sm font-extrabold text-gray-700">${weather.windSpeed}</p>
                    </div>
                  </div>
                </div>

                <!-- Weather Alerts -->
                <div class="mt-6 p-3 bg-amber-50 border border-amber-200/50 rounded-xl flex gap-2">
                  <i data-lucide="alert-triangle" class="w-5 h-5 text-amber-600 shrink-0 mt-0.5"></i>
                  <div class="text-xs text-amber-800">
                    <span class="font-bold">Weather Warning:</span> ${weather.alerts[0].message}
                  </div>
                </div>
              </div>
            </div>

            <!-- Farm Overview Card -->
            <div class="md:col-span-7 glass-card p-6 rounded-3xl flex flex-col justify-between">
              <div>
                <p class="text-xs font-bold uppercase tracking-wider text-gray-400 mb-4">Farm Overview</p>
                <div class="grid grid-cols-3 gap-4">
                  <div class="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-100">
                    <span class="text-[10px] text-emerald-700 font-bold uppercase block mb-1">Land Area</span>
                    <span class="text-xl font-bold text-gray-800">${user.landArea || 'N/A'} Acres</span>
                  </div>
                  <div class="p-4 bg-blue-50/50 rounded-2xl border border-blue-100">
                    <span class="text-[10px] text-blue-700 font-bold uppercase block mb-1">Soil Type</span>
                    <span class="text-sm font-bold text-gray-800 truncate block mt-1">${user.soilType || 'Unassigned'}</span>
                  </div>
                  <div class="p-4 bg-purple-50/50 rounded-2xl border border-purple-100">
                    <span class="text-[10px] text-purple-700 font-bold uppercase block mb-1">Current Crop</span>
                    <span class="text-sm font-bold text-gray-800 truncate block mt-1">${currentCrop ? currentCrop.name : 'None Selected'}</span>
                  </div>
                </div>
              </div>

              <!-- Action/Advisory Info -->
              <div class="mt-6 p-4 bg-green-500/5 border border-green-500/10 rounded-2xl flex items-center justify-between gap-4">
                <div class="flex items-center gap-3">
                  <div class="p-2.5 bg-green-500/10 text-green-700 rounded-xl">
                    <i data-lucide="lightbulb" class="w-5 h-5"></i>
                  </div>
                  <div>
                    <h4 class="text-xs font-bold text-gray-700">Today's Smart Farming Tip:</h4>
                    <p class="text-xs text-gray-500 mt-0.5">${weather.advice[0]}</p>
                  </div>
                </div>
                <button id="btn-crop-rec-go" class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-1 shrink-0">
                  <span>Optimize</span>
                  <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
                </button>
              </div>
            </div>
          </div>

          <!-- Quick Actions Grid -->
          <div>
            <h3 class="text-lg font-bold text-gray-900 mb-4">Quick Advisory & Tools</h3>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
              <!-- Crop Recommendation -->
              <button id="qa-crop" class="glass-card p-5 rounded-2xl hover:scale-[1.02] border border-white hover:border-green-200 transition text-left group">
                <div class="p-3 bg-amber-500/10 text-amber-600 rounded-xl w-12 h-12 flex items-center justify-center mb-4 group-hover:bg-amber-500 group-hover:text-white transition">
                  <i data-lucide="sparkles" class="w-6 h-6"></i>
                </div>
                <h4 class="font-bold text-gray-800 text-sm">AI Crop Match</h4>
                <p class="text-[11px] text-gray-400 mt-1">Recommend profitable seed varieties</p>
              </button>

              <!-- Profit Calculator -->
              <button id="qa-profit" class="glass-card p-5 rounded-2xl hover:scale-[1.02] border border-white hover:border-green-200 transition text-left group">
                <div class="p-3 bg-emerald-500/10 text-emerald-600 rounded-xl w-12 h-12 flex items-center justify-center mb-4 group-hover:bg-emerald-500 group-hover:text-white transition">
                  <i data-lucide="calculator" class="w-6 h-6"></i>
                </div>
                <h4 class="font-bold text-gray-800 text-sm">Profit Calculator</h4>
                <p class="text-[11px] text-gray-400 mt-1">Predict ROI on farm expenditures</p>
              </button>

              <!-- Disease Detection -->
              <button id="qa-disease" class="glass-card p-5 rounded-2xl hover:scale-[1.02] border border-white hover:border-green-200 transition text-left group">
                <div class="p-3 bg-rose-500/10 text-rose-600 rounded-xl w-12 h-12 flex items-center justify-center mb-4 group-hover:bg-rose-500 group-hover:text-white transition">
                  <i data-lucide="scan" class="w-6 h-6"></i>
                </div>
                <h4 class="font-bold text-gray-800 text-sm">Disease Scan</h4>
                <p class="text-[11px] text-gray-400 mt-1">Scan leaves to detect infections</p>
              </button>

              <!-- Expense Tracker -->
              <button id="qa-expenses" class="glass-card p-5 rounded-2xl hover:scale-[1.02] border border-white hover:border-green-200 transition text-left group">
                <div class="p-3 bg-blue-500/10 text-blue-600 rounded-xl w-12 h-12 flex items-center justify-center mb-4 group-hover:bg-blue-500 group-hover:text-white transition">
                  <i data-lucide="trending-up" class="w-6 h-6"></i>
                </div>
                <h4 class="font-bold text-gray-800 text-sm">Expenses & Yield</h4>
                <p class="text-[11px] text-gray-400 mt-1">Log costs: ₹${totalExpenses} spent</p>
              </button>
            </div>
          </div>
        </div>
      `;
    },

    init(appState, navigateTo) {
      document.getElementById('btn-edit-farm')?.addEventListener('click', () => navigateTo('profile'));
      document.getElementById('btn-crop-rec-go')?.addEventListener('click', () => navigateTo('crop-recommendation'));
      document.getElementById('qa-crop')?.addEventListener('click', () => navigateTo('crop-recommendation'));
      document.getElementById('qa-profit')?.addEventListener('click', () => navigateTo('profit-calculator'));
      document.getElementById('qa-disease')?.addEventListener('click', () => navigateTo('disease-detection'));
      document.getElementById('qa-expenses')?.addEventListener('click', () => navigateTo('expenses'));
    }
  },

  // ==========================================
  // 3. AI CROP RECOMMENDATION SYSTEM
  // ==========================================
  CropRecommendation: {
    render(appState) {
      const user = appState.user;
      return `
        <div class="space-y-6 page-fade-in">
          <div class="flex items-center gap-3">
            <button id="btn-back" class="p-2 hover:bg-gray-100 rounded-xl text-gray-500 transition">
              <i data-lucide="arrow-left" class="w-5 h-5"></i>
            </button>
            <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <i data-lucide="sparkles" class="text-amber-500 w-6 h-6"></i>
              AI Crop Recommendation Engine
            </h2>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <!-- Parameters Form -->
            <form id="form-crop-rec" class="lg:col-span-4 glass-card p-6 rounded-3xl border border-white/60 space-y-4">
              <h3 class="text-sm font-bold text-green-800 uppercase tracking-wide">Optimization Inputs</h3>
              
              <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Farming Season</label>
                <select id="rec-season" class="block w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500/20 bg-white text-sm">
                  <option value="Kharif">Kharif (Monsoon/Summer)</option>
                  <option value="Rabi">Rabi (Winter)</option>
                  <option value="Zaid">Zaid (Spring/Short Crop)</option>
                </select>
              </div>

              <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Soil Type</label>
                <select id="rec-soil" class="block w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500/20 bg-white text-sm">
                  <option value="Black Soil" ${user.soilType === 'Black Soil' ? 'selected' : ''}>Black Soil</option>
                  <option value="Loamy" ${user.soilType === 'Loamy' ? 'selected' : ''}>Loamy Soil</option>
                  <option value="Clayey" ${user.soilType === 'Clayey' ? 'selected' : ''}>Clayey Soil</option>
                  <option value="Sandy Loam" ${user.soilType === 'Sandy Loam' ? 'selected' : ''}>Sandy Loam</option>
                </select>
              </div>

              <div class="grid grid-cols-2 gap-2">
                <div>
                  <label class="block text-xs font-semibold text-gray-500 mb-1">Land Size (Acres)</label>
                  <input type="number" id="rec-land" required value="${user.landArea || 1}" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-sm bg-white/50">
                </div>
                <div>
                  <label class="block text-xs font-semibold text-gray-500 mb-1">Budget Limit (INR)</label>
                  <input type="number" id="rec-budget" required value="${user.budget || 50000}" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-sm bg-white/50">
                </div>
              </div>

              <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Irrigation Method</label>
                <select id="rec-irrigation" class="block w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500/20 bg-white text-sm">
                  <option value="Drip Irrigation">Drip Irrigation (Water-efficient)</option>
                  <option value="Sprinkler Irrigation">Sprinkler Irrigation</option>
                  <option value="Flood Irrigation">Flood Irrigation (High water dependency)</option>
                </select>
              </div>

              <button type="submit" class="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2">
                <i data-lucide="cpu" class="w-4 h-4"></i>
                <span>Generate Recommendations</span>
              </button>
            </form>

            <!-- Recommendations Outputs -->
            <div id="rec-results-pane" class="lg:col-span-8 space-y-6">
              <div class="glass-card p-8 rounded-3xl border border-white/60 flex flex-col items-center justify-center text-center text-gray-500 min-h-[300px]">
                <i data-lucide="calculator" class="w-12 h-12 text-green-300 mb-3 animate-bounce"></i>
                <h4 class="font-bold text-gray-700">Ready to Analyze</h4>
                <p class="text-sm text-gray-400 mt-1 max-w-sm">Provide your soil, budget, and land area on the left. The AI model will calculate maximum returns.</p>
              </div>
            </div>
          </div>
        </div>
      `;
    },

    init(appState, navigateTo) {
      document.getElementById('btn-back').addEventListener('click', () => navigateTo('farmer-dashboard'));

      const form = document.getElementById('form-crop-rec');
      const resultsPane = document.getElementById('rec-results-pane');

      form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Read inputs
        const inputs = {
          season: document.getElementById('rec-season').value,
          soilType: document.getElementById('rec-soil').value,
          landArea: document.getElementById('rec-land').value,
          budget: document.getElementById('rec-budget').value,
          irrigationMethod: document.getElementById('rec-irrigation').value
        };

        // Render loading state
        resultsPane.innerHTML = `
          <div class="glass-card p-8 rounded-3xl border border-white/60 flex flex-col items-center justify-center text-center min-h-[300px]">
            <div class="w-12 h-12 rounded-full border-4 border-green-500 border-t-transparent animate-spin mb-4"></div>
            <h4 class="font-bold text-gray-700">Gemini AI Model Analyzing Soil & Market Data...</h4>
            <p class="text-xs text-gray-400 mt-1">Matching against regional weather forecasts & crop history</p>
          </div>
        `;

        setTimeout(() => {
          const recs = GeminiService.recommendCrops(inputs);
          
          if (recs.length === 0) {
            resultsPane.innerHTML = `<div class="p-6 text-center text-rose-500">No crops matched this configuration. Try adjustments.</div>`;
            return;
          }

          const bestCrop = recs[0];
          const runnerUps = recs.slice(1, 3);

          let bestHTML = `
            <div class="relative glass-card border-2 border-emerald-500 p-6 rounded-3xl overflow-hidden bg-gradient-to-br from-emerald-50/20 to-white/40">
              <div class="absolute top-0 right-0 bg-emerald-500 text-white text-[10px] uppercase font-bold tracking-wider px-4 py-1.5 rounded-bl-2xl">
                🏆 Best Crop Recommendation
              </div>
              
              <div class="flex flex-col md:flex-row gap-6 mt-2">
                <img src="${bestCrop.image}" class="w-full md:w-44 h-32 object-cover rounded-2xl shadow-sm">
                <div class="flex-1 space-y-2">
                  <div class="flex items-center gap-2">
                    <h3 class="text-2xl font-extrabold text-gray-900">${bestCrop.name}</h3>
                    <span class="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full">${bestCrop.matchScore}% Match Score</span>
                  </div>
                  
                  <div class="grid grid-cols-2 md:grid-cols-3 gap-3 pt-2">
                    <div>
                      <p class="text-[10px] text-gray-400 font-bold">EST. INVESTMENT</p>
                      <p class="text-sm font-bold text-gray-800">₹${bestCrop.totalInvestment.toLocaleString()}</p>
                    </div>
                    <div>
                      <p class="text-[10px] text-gray-400 font-bold">EST. NET PROFIT</p>
                      <p class="text-sm font-extrabold text-emerald-600">₹${bestCrop.netProfit.toLocaleString()}</p>
                    </div>
                    <div>
                      <p class="text-[10px] text-gray-400 font-bold">ROI</p>
                      <p class="text-sm font-bold text-gray-800">${bestCrop.roi}%</p>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Indicators Bar -->
              <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-4 border-t border-gray-100/50">
                <div class="text-center p-2 rounded-xl bg-white/40">
                  <span class="text-[9px] text-gray-400 font-bold uppercase block">Water Need</span>
                  <span class="text-xs font-semibold text-blue-700">${bestCrop.waterRequirement}</span>
                </div>
                <div class="text-center p-2 rounded-xl bg-white/40">
                  <span class="text-[9px] text-gray-400 font-bold uppercase block">Risk Factor</span>
                  <span class="text-xs font-semibold ${bestCrop.riskScore === 'Low' ? 'text-green-600' : (bestCrop.riskScore === 'Medium' ? 'text-amber-600' : 'text-rose-600')}">${bestCrop.riskScore}</span>
                </div>
                <div class="text-center p-2 rounded-xl bg-white/40">
                  <span class="text-[9px] text-gray-400 font-bold uppercase block">Market Demand</span>
                  <span class="text-xs font-semibold text-gray-700">${bestCrop.demandScore}/100</span>
                </div>
                <div class="text-center p-2 rounded-xl bg-white/40">
                  <span class="text-[9px] text-gray-400 font-bold uppercase block">Soil Health</span>
                  <span class="text-xs font-semibold text-emerald-700">Eco-Friendly</span>
                </div>
              </div>

              <div class="mt-5 flex justify-end gap-2">
                <button id="btn-select-crop" data-id="${bestCrop.id}" class="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-1.5">
                  <i data-lucide="check" class="w-4 h-4"></i>
                  <span>Plant Current Crop</span>
                </button>
              </div>
            </div>
          `;

          let runnerHTML = `
            <div class="space-y-4">
              <h4 class="text-sm font-bold text-gray-500 uppercase tracking-wide">Alternative Crop Options</h4>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          `;

          runnerUps.forEach(crop => {
            runnerHTML += `
              <div class="glass-card p-5 rounded-2xl flex gap-4 hover:scale-[1.01] transition border border-white">
                <img src="${crop.image}" class="w-20 h-20 object-cover rounded-xl shrink-0">
                <div class="flex-1 min-w-0">
                  <h4 class="font-bold text-gray-800 truncate">${crop.name}</h4>
                  <p class="text-[10px] text-emerald-600 font-bold mt-0.5">${crop.matchScore}% Match</p>
                  <div class="flex justify-between items-center mt-3 pt-2 border-t border-gray-50">
                    <div>
                      <span class="text-[9px] text-gray-400 block font-bold uppercase">ROI</span>
                      <span class="text-xs font-extrabold text-gray-700">${crop.roi}%</span>
                    </div>
                    <div>
                      <span class="text-[9px] text-gray-400 block font-bold uppercase">Net Profit</span>
                      <span class="text-xs font-bold text-gray-700">₹${crop.netProfit.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            `;
          });

          runnerHTML += `</div></div>`;

          resultsPane.innerHTML = bestHTML + runnerHTML;
          lucide.createIcons();

          // Add planting select callback
          document.getElementById('btn-select-crop').addEventListener('click', (e) => {
            const cropId = e.currentTarget.getAttribute('data-id');
            LocalDB.updateUser(user.id, { currentCrop: cropId });
            window.app.showToast(`Updated active crop to ${bestCrop.name}!`, "success");
            navigateTo('farmer-dashboard');
          });

        }, 1200);
      });
    }
  },

  // ==========================================
  // 4. PROFIT CALCULATOR ENGINE
  // ==========================================
  ProfitCalculator: {
    render(appState) {
      const user = appState.user;
      
      let selectOptions = '';
      CROPS_DB.forEach(c => {
        selectOptions += `<option value="${c.id}" ${user.currentCrop === c.id ? 'selected' : ''}>${c.name}</option>`;
      });

      return `
        <div class="space-y-6 page-fade-in">
          <div class="flex items-center gap-3">
            <button id="btn-back" class="p-2 hover:bg-gray-100 rounded-xl text-gray-500 transition">
              <i data-lucide="arrow-left" class="w-5 h-5"></i>
            </button>
            <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <i data-lucide="calculator" class="text-emerald-600 w-6 h-6"></i>
              Profit Prediction Engine
            </h2>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <!-- Inputs Panel -->
            <form id="form-profit" class="lg:col-span-5 glass-card p-6 rounded-3xl border border-white/60 space-y-4">
              <h3 class="text-sm font-bold text-green-800 uppercase tracking-wide mb-2">Cost Breakdowns</h3>
              
              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label class="block text-xs font-semibold text-gray-500 mb-1">Target Crop</label>
                  <select id="calc-crop" class="block w-full px-3 py-2 border border-gray-200 rounded-xl bg-white text-xs">
                    ${selectOptions}
                  </select>
                </div>
                <div>
                  <label class="block text-xs font-semibold text-gray-500 mb-1">Land Size (Acres)</label>
                  <input type="number" id="calc-land" required value="${user.landArea || 1}" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs bg-white/50">
                </div>
              </div>

              <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Seed Cost (₹)</label>
                <input type="number" id="cost-seed" value="2500" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
              </div>

              <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Fertilizer & Manure (₹)</label>
                <input type="number" id="cost-fertilizer" value="3800" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
              </div>

              <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Labour Wages (₹)</label>
                <input type="number" id="cost-labour" value="6000" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
              </div>

              <div class="grid grid-cols-2 gap-2">
                <div>
                  <label class="block text-xs font-semibold text-gray-500 mb-1">Pesticides (₹)</label>
                  <input type="number" id="cost-pesticide" value="1500" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
                </div>
                <div>
                  <label class="block text-xs font-semibold text-gray-500 mb-1">Transport (₹)</label>
                  <input type="number" id="cost-transport" value="1200" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
                </div>
              </div>

              <button type="submit" class="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2">
                <i data-lucide="calculator" class="w-4 h-4"></i>
                <span>Forecast Returns</span>
              </button>
            </form>

            <!-- Results Output & Graph -->
            <div id="profit-results" class="lg:col-span-7 space-y-6">
              <div class="glass-card p-8 rounded-3xl border border-white/60 flex flex-col items-center justify-center text-center text-gray-500 min-h-[300px]">
                <i data-lucide="trending-up" class="w-12 h-12 text-green-300 mb-3 animate-pulse"></i>
                <h4 class="font-bold text-gray-700">Calculate Expected ROI</h4>
                <p class="text-sm text-gray-400 mt-1 max-w-sm">Enter your cost estimations. AntiGravity ML model will output confidence score, yield projections, and visual profit metrics.</p>
              </div>
            </div>
          </div>
        </div>
      `;
    },

    init(appState, navigateTo) {
      document.getElementById('btn-back').addEventListener('click', () => navigateTo('farmer-dashboard'));

      const form = document.getElementById('form-profit');
      const resultsPane = document.getElementById('profit-results');

      // Autofill default costs based on crop selection
      const calcCropSelect = document.getElementById('calc-crop');
      const calcLandInput = document.getElementById('calc-land');

      const autofillCosts = () => {
        const cropId = calcCropSelect.value;
        const acres = parseFloat(calcLandInput.value) || 1;
        const crop = CROPS_DB.find(c => c.id === cropId);
        if (crop) {
          document.getElementById('cost-seed').value = crop.avgSeedCostPerAcre * acres;
          document.getElementById('cost-fertilizer').value = crop.avgFertilizerCostPerAcre * acres;
          document.getElementById('cost-labour').value = crop.avgLabourCostPerAcre * acres;
          document.getElementById('cost-pesticide').value = crop.avgPesticideCostPerAcre * acres;
          document.getElementById('cost-transport').value = crop.avgTransportCostPerAcre * acres;
        }
      };

      calcCropSelect.addEventListener('change', autofillCosts);
      calcLandInput.addEventListener('input', autofillCosts);
      autofillCosts(); // Run initially

      form.addEventListener('submit', (e) => {
        e.preventDefault();

        const inputs = {
          cropId: calcCropSelect.value,
          landSize: calcLandInput.value,
          seedCost: document.getElementById('cost-seed').value,
          fertilizerCost: document.getElementById('cost-fertilizer').value,
          labourCost: document.getElementById('cost-labour').value,
          pesticideCost: document.getElementById('cost-pesticide').value,
          transportCost: document.getElementById('cost-transport').value
        };

        const result = GeminiService.predictProfit(inputs);
        const cropMeta = CROPS_DB.find(c => c.id === inputs.cropId);

        resultsPane.innerHTML = `
          <div class="glass-card p-6 rounded-3xl border border-white/60 space-y-6">
            <div class="flex justify-between items-start">
              <div>
                <p class="text-xs font-bold uppercase tracking-wider text-gray-400">Estimated Net Profit</p>
                <h3 class="text-3xl font-extrabold text-emerald-600 mt-1">₹${result.netProfit.toLocaleString()}</h3>
              </div>
              <div class="text-right">
                <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-bold">ROI: ${result.roi}%</span>
                <p class="text-[10px] text-gray-400 mt-1 font-bold">Confidence: ${result.confidenceScore}%</p>
              </div>
            </div>

            <!-- Dashboard Stats Grid -->
            <div class="grid grid-cols-3 gap-3">
              <div class="p-3 bg-gray-50 rounded-xl">
                <span class="text-[9px] text-gray-400 font-bold block">TOTAL INVESTMENT</span>
                <span class="text-sm font-bold text-gray-700">₹${result.totalInvestment.toLocaleString()}</span>
              </div>
              <div class="p-3 bg-gray-50 rounded-xl">
                <span class="text-[9px] text-gray-400 font-bold block">EXPECTED YIELD</span>
                <span class="text-sm font-bold text-gray-700">${result.yieldEstimation} Quintal</span>
              </div>
              <div class="p-3 bg-gray-50 rounded-xl">
                <span class="text-[9px] text-gray-400 font-bold block">MANDI RATE</span>
                <span class="text-sm font-bold text-gray-700">₹${cropMeta.mandiPricePerQuintal}/Q</span>
              </div>
            </div>

            <!-- Profit Comparison Graph -->
            <div class="relative h-64 bg-white/40 rounded-2xl p-4 border border-gray-100 flex items-center justify-center">
              <canvas id="chart-profit-prediction"></canvas>
            </div>

            <div class="flex justify-end gap-3">
              <button id="btn-save-as-expense" class="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 font-bold text-xs rounded-xl transition">
                Log Costs to Tracker
              </button>
            </div>
          </div>
        `;

        lucide.createIcons();

        // Render profit projection bar chart
        const ctx = document.getElementById('chart-profit-prediction').getContext('2d');
        new Chart(ctx, {
          type: 'bar',
          data: {
            labels: ['Total Investment', 'Expected Revenue', 'Net Profit'],
            datasets: [{
              label: 'Amount (INR)',
              data: [result.totalInvestment, result.expectedRevenue, result.netProfit],
              backgroundColor: ['#f43f5e', '#3b82f6', '#10b981'],
              borderRadius: 8,
              borderWidth: 0,
              maxBarThickness: 45
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: { display: false }
            },
            scales: {
              y: {
                beginAtZero: true,
                grid: { color: 'rgba(0, 0, 0, 0.05)' }
              },
              x: {
                grid: { display: false }
              }
            }
          }
        });

        // Add expense logging action
        document.getElementById('btn-save-as-expense').addEventListener('click', () => {
          const categories = ['Seeds', 'Fertilizer', 'Labour', 'Pesticides', 'Transport'];
          const costs = [inputs.seedCost, inputs.fertilizerCost, inputs.labourCost, inputs.pesticideCost, inputs.transportCost];

          categories.forEach((cat, idx) => {
            const amount = parseFloat(costs[idx]) || 0;
            if (amount > 0) {
              LocalDB.addExpense({
                farmerId: appState.user.id,
                cropId: inputs.cropId,
                category: cat,
                amount,
                date: new Date().toISOString().split('T')[0],
                notes: `Auto-logged from Profit Calculator prediction`
              });
            }
          });
          window.app.showToast("All costs logged into Expense Tracker!", "success");
        });
      });
    }
  },

  // ==========================================
  // 5. WEATHER RISK MANAGEMENT
  // ==========================================
  // Built directly inside FarmerDashboard/AI suggestions

  // ==========================================
  // 6. AI DISEASE DETECTION
  // ==========================================
  DiseaseDetection: {
    render(appState) {
      return `
        <div class="space-y-6 page-fade-in">
          <div class="flex items-center gap-3">
            <button id="btn-back" class="p-2 hover:bg-gray-100 rounded-xl text-gray-500 transition">
              <i data-lucide="arrow-left" class="w-5 h-5"></i>
            </button>
            <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <i data-lucide="scan" class="text-rose-600 w-6 h-6 animate-pulse"></i>
              AI Disease Detection Demo
            </h2>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-12 gap-6">
            <!-- Upload Panel -->
            <div class="md:col-span-5 glass-card p-6 rounded-3xl border border-white/60 space-y-4 flex flex-col justify-between">
              <div>
                <h3 class="text-sm font-bold text-gray-700 uppercase tracking-wide mb-2">Upload Crop Foliage</h3>
                <p class="text-xs text-gray-400">Take a picture of infected crop leaves or upload a file. The computer vision scanner will process structural spots, mildew templates, and vein curls.</p>
              </div>

              <!-- Upload box -->
              <div id="drop-zone" class="border-2 border-dashed border-gray-200 hover:border-emerald-400 rounded-2xl p-8 text-center cursor-pointer bg-white/40 hover:bg-emerald-50/20 transition-all flex flex-col items-center justify-center min-h-[220px] relative overflow-hidden">
                <input type="file" id="file-leaf" accept="image/*" class="absolute inset-0 opacity-0 cursor-pointer">
                <div id="upload-prompt" class="space-y-2">
                  <div class="p-4 bg-emerald-50 text-emerald-600 rounded-full inline-block">
                    <i data-lucide="camera" class="w-8 h-8"></i>
                  </div>
                  <p class="text-sm font-bold text-gray-700">Drag & Drop Image Here</p>
                  <p class="text-xs text-gray-400">Supports PNG, JPG (Max 5MB)</p>
                </div>
                <!-- Leaf Preview -->
                <div id="leaf-preview" class="hidden w-full h-full absolute inset-0 bg-cover bg-center">
                  <div class="scan-line absolute w-full left-0 hidden"></div>
                </div>
              </div>

              <!-- Sample selector -->
              <div>
                <p class="text-xs font-bold text-gray-400 uppercase tracking-wide mb-2">Try Demo Leaf Samples:</p>
                <div class="grid grid-cols-3 gap-2">
                  <button data-sample="tomato" class="btn-sample-leaf px-2.5 py-2 bg-gray-100 hover:bg-green-50 text-[11px] font-bold text-gray-600 rounded-xl border border-gray-200 transition">Tomato Blight</button>
                  <button data-sample="cotton" class="btn-sample-leaf px-2.5 py-2 bg-gray-100 hover:bg-green-50 text-[11px] font-bold text-gray-600 rounded-xl border border-gray-200 transition">Cotton Curl</button>
                  <button data-sample="rice" class="btn-sample-leaf px-2.5 py-2 bg-gray-100 hover:bg-green-50 text-[11px] font-bold text-gray-600 rounded-xl border border-gray-200 transition">Rice Blast</button>
                </div>
              </div>
            </div>

            <!-- Diagnostics Panel -->
            <div id="disease-results" class="md:col-span-7">
              <div class="glass-card p-8 rounded-3xl border border-white/60 flex flex-col items-center justify-center text-center text-gray-500 min-h-[350px]">
                <i data-lucide="shield-alert" class="w-12 h-12 text-rose-300 mb-3"></i>
                <h4 class="font-bold text-gray-700">Scan Pending</h4>
                <p class="text-sm text-gray-400 mt-1 max-w-sm">Provide an image to activate the diagnostic scanner. The model will isolate leaf spots and recommend treatments.</p>
              </div>
            </div>
          </div>
        </div>
      `;
    },

    init(appState, navigateTo) {
      document.getElementById('btn-back').addEventListener('click', () => navigateTo('farmer-dashboard'));

      const fileInput = document.getElementById('file-leaf');
      const dropZone = document.getElementById('drop-zone');
      const uploadPrompt = document.getElementById('upload-prompt');
      const leafPreview = document.getElementById('leaf-preview');
      const resultsPane = document.getElementById('disease-results');
      const scanLine = leafPreview.querySelector('.scan-line');

      const runDiagnosis = (fileName, imageSrc) => {
        // Show scan preview
        uploadPrompt.classList.add('hidden');
        leafPreview.classList.remove('hidden');
        leafPreview.style.backgroundImage = `url('${imageSrc}')`;
        scanLine.classList.remove('hidden');

        // Show diagnostic loader
        resultsPane.innerHTML = `
          <div class="glass-card p-8 rounded-3xl border border-white/60 flex flex-col items-center justify-center text-center min-h-[350px] space-y-4">
            <div class="w-12 h-12 rounded-full border-4 border-rose-500 border-t-transparent animate-spin"></div>
            <div>
              <h4 class="font-bold text-gray-700">Computer Vision Scanning Spots...</h4>
              <p class="text-xs text-gray-400 mt-1">Comparing chlorotic spots and structural curls against disease libraries</p>
            </div>
          </div>
        `;

        const activeCropName = CROPS_DB.find(c => c.id === appState.user.currentCrop)?.name || "Crop";

        DiseaseService.detectDisease(fileName, activeCropName).then(report => {
          // Stop scan line
          scanLine.classList.add('hidden');

          resultsPane.innerHTML = `
            <div class="glass-card p-6 rounded-3xl border border-white/60 space-y-6 page-fade-in">
              <div class="flex justify-between items-start border-b border-gray-100 pb-4">
                <div>
                  <p class="text-[10px] text-gray-400 font-extrabold uppercase tracking-wide">Analysis Result</p>
                  <h3 class="text-xl font-extrabold text-gray-900 mt-0.5">${report.name}</h3>
                </div>
                <div class="text-right">
                  <span class="px-2.5 py-0.5 bg-rose-100 text-rose-800 text-xs font-bold rounded-full">Confidence: ${report.confidence}</span>
                </div>
              </div>

              <div>
                <p class="text-xs font-extrabold text-gray-500 uppercase tracking-wide">Primary Cause:</p>
                <p class="text-xs text-gray-600 mt-1">${report.cause}</p>
              </div>

              <div>
                <p class="text-xs font-extrabold text-gray-500 uppercase tracking-wide">Visible Symptoms:</p>
                <p class="text-xs text-gray-600 mt-1">${report.symptoms}</p>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <!-- Organic Solution -->
                <div class="p-4 bg-emerald-50/50 border border-emerald-100 rounded-2xl">
                  <div class="flex items-center gap-1.5 text-emerald-800 font-bold text-xs">
                    <i data-lucide="leaf" class="w-4 h-4"></i>
                    <span>Organic Treatment</span>
                  </div>
                  <p class="text-[11px] text-gray-600 mt-2 leading-relaxed">${report.organicSolution}</p>
                </div>
                <!-- Chemical Solution -->
                <div class="p-4 bg-amber-50/50 border border-amber-100 rounded-2xl">
                  <div class="flex items-center gap-1.5 text-amber-800 font-bold text-xs">
                    <i data-lucide="flask-conical" class="w-4 h-4"></i>
                    <span>Chemical Treatment</span>
                  </div>
                  <p class="text-[11px] text-gray-600 mt-2 leading-relaxed">${report.chemicalSolution}</p>
                </div>
              </div>

              <!-- Prevention methods -->
              <div class="p-4 bg-gray-50 border border-gray-100 rounded-2xl">
                <p class="text-xs font-extrabold text-gray-700 uppercase tracking-wide">Preventive Advice:</p>
                <p class="text-xs text-gray-600 mt-1 leading-relaxed">${report.preventionMethods}</p>
              </div>
            </div>
          `;
          lucide.createIcons();
        });
      };

      // File input change
      fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            runDiagnosis(file.name, event.target.result);
          };
          reader.readAsDataURL(file);
        }
      });

      // Demo sample buttons click
      document.querySelectorAll('.btn-sample-leaf').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const sampleType = e.currentTarget.getAttribute('data-sample');
          let name = 'Sample.jpg';
          let url = '';
          if (sampleType === 'tomato') {
            name = 'tomato_blight_spots.jpg';
            url = 'https://images.unsplash.com/photo-1592878904946-b3cd8ae243d0?w=600&auto=format&fit=crop&q=60';
          } else if (sampleType === 'cotton') {
            name = 'cotton_curl_vector.jpg';
            url = 'https://images.unsplash.com/photo-1594489428504-5c0c480a15fd?w=600&auto=format&fit=crop&q=60';
          } else {
            name = 'rice_blast_collar.jpg';
            url = 'https://images.unsplash.com/photo-1536882240095-0379873feb4e?w=600&auto=format&fit=crop&q=60';
          }
          runDiagnosis(name, url);
        });
      });
    }
  },

  // ==========================================
  // 7. EXPENSE TRACKER MODULE
  // ==========================================
  Expenses: {
    render(appState) {
      const expenses = LocalDB.getExpenses(appState.user.id);
      
      let selectOptions = '';
      CROPS_DB.forEach(c => {
        selectOptions += `<option value="${c.id}" ${appState.user.currentCrop === c.id ? 'selected' : ''}>${c.name}</option>`;
      });

      return `
        <div class="space-y-6 page-fade-in">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-3">
              <button id="btn-back" class="p-2 hover:bg-gray-100 rounded-xl text-gray-500 transition">
                <i data-lucide="arrow-left" class="w-5 h-5"></i>
              </button>
              <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <i data-lucide="trending-up" class="text-blue-600 w-6 h-6"></i>
                Expense & Yield Tracker
              </h2>
            </div>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <!-- Log Form -->
            <form id="form-expense" class="lg:col-span-4 glass-card p-6 rounded-3xl border border-white/60 space-y-4">
              <h3 class="text-sm font-bold text-gray-700 uppercase tracking-wide mb-2">Log Farm Expenditure</h3>
              
              <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Target Crop</label>
                <select id="exp-crop" class="block w-full px-3 py-2 border border-gray-200 rounded-xl bg-white text-xs">
                  ${selectOptions}
                </select>
              </div>

              <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Expense Category</label>
                <select id="exp-category" class="block w-full px-3 py-2 border border-gray-200 rounded-xl bg-white text-xs">
                  <option value="Seeds">Seeds</option>
                  <option value="Fertilizer">Fertilizer</option>
                  <option value="Labour">Labour Wages</option>
                  <option value="Equipment">Equipment / Tractor Hire</option>
                  <option value="Pesticides">Pesticides / Insecticides</option>
                  <option value="Transport">Transport</option>
                  <option value="Irrigation">Irrigation / Diesel Pump</option>
                </select>
              </div>

              <div class="grid grid-cols-2 gap-2">
                <div>
                  <label class="block text-xs font-semibold text-gray-500 mb-1">Amount (₹)</label>
                  <input type="number" id="exp-amount" required placeholder="INR" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
                </div>
                <div>
                  <label class="block text-xs font-semibold text-gray-500 mb-1">Transaction Date</label>
                  <input type="date" id="exp-date" required class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
                </div>
              </div>

              <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Notes / Invoice No.</label>
                <input type="text" id="exp-notes" placeholder="e.g. Bought 2 bags urea" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
              </div>

              <button type="submit" class="w-full py-2.5 bg-gradient-to-r from-blue-600 to-sky-600 hover:from-blue-700 hover:to-sky-700 text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2">
                <i data-lucide="plus-circle" class="w-4 h-4"></i>
                <span>Log Transaction</span>
              </button>
            </form>

            <!-- Expense Charts and List -->
            <div class="lg:col-span-8 space-y-6">
              <!-- Visual Chart -->
              <div class="glass-card p-6 rounded-3xl border border-white/60">
                <h3 class="text-sm font-bold text-gray-700 uppercase tracking-wide mb-4">Expenditure Breakdown</h3>
                <div class="relative h-64 bg-white/40 rounded-2xl p-4 border border-gray-100 flex items-center justify-center">
                  <canvas id="chart-expense-breakdown"></canvas>
                </div>
              </div>

              <!-- Transaction List -->
              <div class="glass-card p-6 rounded-3xl border border-white/60">
                <h3 class="text-sm font-bold text-gray-700 uppercase tracking-wide mb-4">Transaction History</h3>
                <div class="max-h-[300px] overflow-y-auto no-scrollbar space-y-2" id="expense-history-list">
                  <!-- Dynamic content -->
                </div>
              </div>
            </div>
          </div>
        </div>
      `;
    },

    init(appState, navigateTo) {
      document.getElementById('btn-back').addEventListener('click', () => navigateTo('farmer-dashboard'));

      const form = document.getElementById('form-expense');
      const dateInput = document.getElementById('exp-date');
      const listPane = document.getElementById('expense-history-list');

      // Default date to today
      dateInput.value = new Date().toISOString().split('T')[0];

      let chartInstance = null;

      const renderHistoryAndChart = () => {
        const expenses = LocalDB.getExpenses(appState.user.id);
        
        // Render List
        if (expenses.length === 0) {
          listPane.innerHTML = `<div class="p-6 text-center text-xs text-gray-400">No transactions logged yet.</div>`;
        } else {
          listPane.innerHTML = expenses.map(e => {
            const cropName = CROPS_DB.find(c => c.id === e.cropId)?.name || 'General';
            return `
              <div class="flex items-center justify-between p-3.5 bg-white/50 border border-gray-100 rounded-xl hover:scale-[1.005] transition-all">
                <div class="flex items-center gap-3">
                  <div class="p-2.5 bg-blue-50 text-blue-600 rounded-xl">
                    <i data-lucide="receipt" class="w-4 h-4"></i>
                  </div>
                  <div>
                    <h4 class="text-xs font-bold text-gray-800">${e.category} (${cropName})</h4>
                    <p class="text-[10px] text-gray-400">${e.date} | ${e.notes || 'No comments'}</p>
                  </div>
                </div>
                <div class="flex items-center gap-3">
                  <span class="text-xs font-extrabold text-red-600">- ₹${e.amount.toLocaleString()}</span>
                  <button data-id="${e.id}" class="btn-delete-expense p-1 hover:bg-rose-50 text-gray-300 hover:text-rose-600 rounded transition">
                    <i data-lucide="trash" class="w-3.5 h-3.5"></i>
                  </button>
                </div>
              </div>
            `;
          }).reverse().join('');
          
          lucide.createIcons();
          
          // Attach delete callbacks
          document.querySelectorAll('.btn-delete-expense').forEach(btn => {
            btn.addEventListener('click', (e) => {
              const expenseId = e.currentTarget.getAttribute('data-id');
              LocalDB.deleteExpense(expenseId);
              window.app.showToast("Expense log deleted.", "success");
              renderHistoryAndChart();
            });
          });
        }

        // Aggregate by Category for Chart
        const categories = {};
        expenses.forEach(e => {
          categories[e.category] = (categories[e.category] || 0) + e.amount;
        });

        const catNames = Object.keys(categories);
        const catValues = Object.values(categories);

        // Render Pie Chart
        const ctx = document.getElementById('chart-expense-breakdown').getContext('2d');
        if (chartInstance) {
          chartInstance.destroy();
        }

        if (catNames.length === 0) {
          ctx.font = '12px sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText('No cost logs to chart', ctx.canvas.width / 2, ctx.canvas.height / 2);
          return;
        }

        chartInstance = new Chart(ctx, {
          type: 'doughnut',
          data: {
            labels: catNames,
            datasets: [{
              data: catValues,
              backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899'],
              borderWidth: 2,
              borderColor: '#ffffff'
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'right',
                labels: { boxWidth: 12, font: { size: 10 } }
              }
            }
          }
        });
      };

      // Handle Submit
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const cropId = document.getElementById('exp-crop').value;
        const category = document.getElementById('exp-category').value;
        const amount = parseFloat(document.getElementById('exp-amount').value) || 0;
        const date = dateInput.value;
        const notes = document.getElementById('exp-notes').value.trim();

        LocalDB.addExpense({
          farmerId: appState.user.id,
          cropId,
          category,
          amount,
          date,
          notes
        });

        window.app.showToast("Expense logged successfully!", "success");
        form.reset();
        dateInput.value = new Date().toISOString().split('T')[0];
        renderHistoryAndChart();
      });

      renderHistoryAndChart();
    }
  },

  // ==========================================
  // 8. AI FARMING ASSISTANT
  // ==========================================
  Assistant: {
    render(appState) {
      const user = appState.user;
      
      let langOptions = '';
      LANGUAGES.forEach(l => {
        langOptions += `<option value="${l.code}" ${user.language === l.code ? 'selected' : ''}>${l.name}</option>`;
      });

      return `
        <div class="h-[80vh] flex flex-col glass-card rounded-3xl border border-white/60 overflow-hidden page-fade-in">
          <!-- Chat Header -->
          <div class="p-4 border-b border-gray-100 flex items-center justify-between bg-white/40">
            <div class="flex items-center gap-3">
              <div class="p-2.5 bg-green-500/10 text-green-700 rounded-xl relative">
                <i data-lucide="bot" class="w-6 h-6"></i>
                <div class="absolute bottom-0.5 right-0.5 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white glow-dot animate-ping"></div>
              </div>
              <div>
                <h3 class="font-bold text-gray-900 text-sm">AI Farming Assistant</h3>
                <p class="text-[10px] text-gray-400">Gemini-Powered Multi-lingual Expert</p>
              </div>
            </div>
            
            <div class="flex items-center gap-2">
              <select id="chat-lang-select" class="px-2 py-1 bg-white border border-gray-200 rounded-lg text-xs font-semibold text-gray-700 outline-none">
                ${langOptions}
              </select>
              <button id="btn-show-key-modal" class="p-1.5 hover:bg-gray-100 text-gray-400 hover:text-gray-600 rounded-lg transition" title="API Settings">
                <i data-lucide="key" class="w-4 h-4"></i>
              </button>
            </div>
          </div>

          <!-- Chat Messages Area -->
          <div id="chat-messages-container" class="flex-1 p-4 overflow-y-auto no-scrollbar space-y-3 bg-slate-50/30">
            <!-- Messages append here -->
          </div>

          <!-- Quick Prompts suggestions -->
          <div class="p-2 border-t border-gray-100 flex gap-2 overflow-x-auto no-scrollbar bg-white/30 scroll-smooth">
            <button class="chat-prompt-pill shrink-0 px-3 py-1 bg-white border border-gray-100 hover:border-green-200 rounded-full text-[11px] text-gray-600 font-bold transition">Which fertilizer is best for paddy?</button>
            <button class="chat-prompt-pill shrink-0 px-3 py-1 bg-white border border-gray-100 hover:border-green-200 rounded-full text-[11px] text-gray-600 font-bold transition">How to prevent cotton leaf curl?</button>
            <button class="chat-prompt-pill shrink-0 px-3 py-1 bg-white border border-gray-100 hover:border-green-200 rounded-full text-[11px] text-gray-600 font-bold transition">What is PM-Kisan subsidy eligibility?</button>
          </div>

          <!-- Chat Input -->
          <form id="form-chat" class="p-3 border-t border-gray-100 bg-white/50 flex gap-2">
            <button type="button" id="btn-chat-mic" class="p-3 bg-gray-100 hover:bg-red-50 text-gray-500 hover:text-red-500 rounded-xl transition flex items-center justify-center shrink-0" title="Voice Input">
              <i data-lucide="mic" class="w-5 h-5"></i>
            </button>
            <input type="text" id="chat-input-text" autocomplete="off" placeholder="Ask about crops, pests, fertilizers..." class="flex-1 px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-500 text-sm">
            <button type="submit" class="p-3 bg-green-600 hover:bg-green-700 text-white rounded-xl shadow-md transition flex items-center justify-center shrink-0">
              <i data-lucide="send" class="w-5 h-5"></i>
            </button>
          </form>

          <!-- API Key Setting Modal overlay -->
          <div id="key-modal" class="hidden absolute inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
            <div class="glass-card w-full max-w-sm p-6 rounded-2xl border border-white/60 space-y-4">
              <div class="flex justify-between items-center">
                <h4 class="font-bold text-gray-800 text-sm">Gemini API Key</h4>
                <button type="button" id="btn-close-key" class="text-gray-400 hover:text-gray-600"><i data-lucide="x" class="w-4 h-4"></i></button>
              </div>
              <p class="text-xs text-gray-400">Insert your Gemini API key from Google AI Studio. This key is saved locally in your browser storage.</p>
              <input type="password" id="gemini-key-input" placeholder="AIzaSy..." class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
              <div class="flex justify-end gap-2">
                <button type="button" id="btn-save-key" class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-xs font-bold rounded-xl shadow-md transition">Save API Key</button>
              </div>
            </div>
          </div>
        </div>
      `;
    },

    init(appState, navigateTo) {
      const messagesContainer = document.getElementById('chat-messages-container');
      const form = document.getElementById('form-chat');
      const textInput = document.getElementById('chat-input-text');
      const langSelect = document.getElementById('chat-lang-select');
      const micBtn = document.getElementById('btn-chat-mic');
      
      const keyModal = document.getElementById('key-modal');
      const showKeyBtn = document.getElementById('btn-show-key-modal');
      const closeKeyBtn = document.getElementById('btn-close-key');
      const saveKeyBtn = document.getElementById('btn-save-key');
      const keyInput = document.getElementById('gemini-key-input');

      // Populate current key
      keyInput.value = GeminiService.getApiKey();

      // Modal Triggers
      showKeyBtn.addEventListener('click', () => keyModal.classList.remove('hidden'));
      closeKeyBtn.addEventListener('click', () => keyModal.classList.add('hidden'));
      saveKeyBtn.addEventListener('click', () => {
        GeminiService.setApiKey(keyInput.value.trim());
        window.app.showToast("Gemini API Key saved!", "success");
        keyModal.classList.add('hidden');
      });

      const appendMessage = (sender, content) => {
        const isBot = sender === 'bot';
        const msgHTML = `
          <div class="flex ${isBot ? 'justify-start' : 'justify-end'}">
            <div class="max-w-[85%] rounded-2xl p-3.5 text-xs shadow-sm ${
              isBot 
                ? 'bg-white border border-gray-100 text-gray-800 rounded-tl-none leading-relaxed' 
                : 'bg-green-600 text-white rounded-tr-none'
            }">
              ${content.replace(/\n/g, '<br>')}
            </div>
          </div>
        `;
        messagesContainer.insertAdjacentHTML('beforeend', msgHTML);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
      };

      // Voice Input simulation
      let isRecording = false;
      micBtn.addEventListener('click', () => {
        if (isRecording) return;
        isRecording = true;
        micBtn.className = "p-3 bg-red-500 text-white rounded-xl animate-pulse transition shrink-0";
        window.app.showToast("Voice capture: Listening...", "info");

        setTimeout(() => {
          micBtn.className = "p-3 bg-gray-100 hover:bg-red-50 text-gray-500 hover:text-red-500 rounded-xl transition shrink-0";
          isRecording = false;
          
          // Generate default speech string based on selected language
          const voiceMocks = {
            en: "What fertilizers should I buy for wheat crop?",
            te: "పత్తి పంట తెగుళ్ళను నివారించడం ఎలా?",
            hi: "धान के लिए कौन सी खाद उपयुक्त है?"
          };
          
          textInput.value = voiceMocks[langSelect.value] || voiceMocks['en'];
          window.app.showToast("Speech captured!", "success");
        }, 3000);
      });

      // Submit Form
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const text = textInput.value.trim();
        if (!text) return;

        textInput.value = '';
        appendMessage('user', text);

        // Typing indicator
        const typingId = 'msg-typing-' + Date.now();
        const typingHTML = `
          <div id="${typingId}" class="flex justify-start">
            <div class="max-w-[80%] rounded-2xl p-3 bg-white border border-gray-100 rounded-tl-none text-xs text-gray-400 flex items-center gap-1">
              <span class="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"></span>
              <span class="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
              <span class="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
            </div>
          </div>
        `;
        messagesContainer.insertAdjacentHTML('beforeend', typingHTML);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;

        try {
          const reply = await GeminiService.askAI(text, langSelect.value);
          document.getElementById(typingId).remove();
          appendMessage('bot', reply);
          
          // Voice Response simulation (Text to Speech mock)
          if (langSelect.value === 'en') {
            window.speechSynthesis?.speak(new SpeechSynthesisUtterance(reply.substring(0, 100)));
          }
        } catch (err) {
          document.getElementById(typingId).remove();
          appendMessage('bot', "Apologies, the connection is slow. Please verify your internet or crop query.");
        }
      });

      // Suggestions pills
      document.querySelectorAll('.chat-prompt-pill').forEach(pill => {
        pill.addEventListener('click', (e) => {
          textInput.value = e.currentTarget.innerText;
          form.dispatchEvent(new Event('submit'));
        });
      });

      // Initial bot welcome message
      const welcomes = {
        en: "Hello! I am KisanMithr, your AI farming assistant. How can I help you today with crops, weather, diseases, or market prices?",
        te: "నమస్తే! నేను కిసాన్ మిత్ర AI సహాయకుడిని. ఈరోజు పంటలు, వాతావరణం లేదా తెగుళ్ల గురించి మీకు ఎలా సహాయం చేయగలను?",
        hi: "नमस्ते! मैं किसानमित्र AI कृषि सहायक हूँ। आज मैं फसलों, मौसम, कीट नियंत्रण या मंडी भाव के बारे में आपकी क्या मदद कर सकता हूँ?"
      };
      
      appendMessage('bot', welcomes[langSelect.value] || welcomes['en']);
      
      langSelect.addEventListener('change', () => {
        messagesContainer.innerHTML = '';
        appendMessage('bot', welcomes[langSelect.value] || welcomes['en']);
      });
    }
  },

  // ==========================================
  // 9. GOVERNMENT SCHEMES MODULE
  // ==========================================
  Schemes: {
    render(appState) {
      return `
        <div class="space-y-6 page-fade-in">
          <div class="flex items-center justify-between">
            <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <i data-lucide="landmark" class="text-green-600 w-6 h-6"></i>
              Government Schemes & Loans
            </h2>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            ${SCHEMES_DB.map(s => `
              <div class="glass-card p-6 rounded-3xl border border-white/60 flex flex-col justify-between hover:scale-[1.01] transition-all group">
                <div class="space-y-3">
                  <div class="flex justify-between items-start">
                    <span class="px-2.5 py-0.5 bg-green-500/10 text-green-700 text-[10px] font-bold rounded-full border border-green-200/30">${s.category}</span>
                  </div>
                  <h3 class="text-base font-extrabold text-gray-900 leading-tight">${s.name}</h3>
                  <div class="space-y-1 mt-3">
                    <p class="text-xs text-gray-400 font-bold uppercase">Eligibility:</p>
                    <p class="text-xs text-gray-600 line-clamp-2">${s.eligibility}</p>
                  </div>
                  <div class="space-y-1">
                    <p class="text-xs text-gray-400 font-bold uppercase">Primary Benefit:</p>
                    <p class="text-xs text-gray-600 line-clamp-2">${s.benefits}</p>
                  </div>
                </div>

                <div class="mt-6 pt-4 border-t border-gray-100/60 flex justify-between items-center">
                  <button data-id="${s.id}" class="btn-scheme-details text-xs font-bold text-green-700 hover:text-green-800 transition flex items-center gap-1">
                    <span>View Required Docs</span>
                    <i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>
                  </button>
                  <a href="${s.link}" target="_blank" class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-1">
                    <span>Apply Online</span>
                    <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                  </a>
                </div>
              </div>
            `).join('')}
          </div>

          <!-- Scheme Detail Modal overlay -->
          <div id="scheme-modal" class="hidden absolute inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
            <div class="glass-card w-full max-w-md p-6 rounded-2xl border border-white/60 space-y-4" id="scheme-modal-content">
              <!-- Dynamically populated -->
            </div>
          </div>
        </div>
      `;
    },

    init(appState, navigateTo) {
      const modal = document.getElementById('scheme-modal');
      const modalContent = document.getElementById('scheme-modal-content');

      document.querySelectorAll('.btn-scheme-details').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = e.currentTarget.getAttribute('data-id');
          const s = SCHEMES_DB.find(scheme => scheme.id === id);
          
          modalContent.innerHTML = `
            <div class="flex justify-between items-center pb-2 border-b border-gray-100">
              <h4 class="font-extrabold text-gray-800 text-sm">Required Documents</h4>
              <button type="button" id="btn-close-scheme" class="text-gray-400 hover:text-gray-600"><i data-lucide="x" class="w-4 h-4"></i></button>
            </div>
            <div class="space-y-3 pt-2">
              <h5 class="font-bold text-xs text-green-700">${s.name}</h5>
              <div class="p-3.5 bg-gray-50 border border-gray-100 rounded-xl">
                <p class="text-xs text-gray-700 font-semibold leading-relaxed">${s.documents}</p>
              </div>
              <p class="text-[10px] text-gray-400">Make sure all details match your Aadhaar bio-link records to avoid delays during verification.</p>
            </div>
          `;
          
          modal.classList.remove('hidden');
          lucide.createIcons();

          document.getElementById('btn-close-scheme').addEventListener('click', () => {
            modal.classList.add('hidden');
          });
        });
      });
    }
  },

  // ==========================================
  // 10. PRODUCT MARKETPLACE MODULE
  // ==========================================
  Marketplace: {
    render(appState) {
      const isFarmer = appState.user.role === 'farmer';
      const products = LocalDB.getProducts();

      return `
        <div class="space-y-6 page-fade-in">
          <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <i data-lucide="shopping-bag" class="text-emerald-600 w-6 h-6"></i>
                KisanMithr Direct Marketplace
              </h2>
              <p class="text-xs text-gray-400">Connecting farm producers directly with health-conscious buyers.</p>
            </div>
            
            ${isFarmer ? `
              <button id="btn-add-product" class="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-bold text-xs rounded-xl shadow-lg transition flex items-center gap-2">
                <i data-lucide="plus-circle" class="w-4 h-4"></i>
                <span>List New Harvest</span>
              </button>
            ` : ''}
          </div>

          <!-- Product Feed Grid -->
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            ${products.length === 0 ? `
              <div class="col-span-full py-12 text-center text-gray-400 text-xs">
                No items currently listed for sale.
              </div>
            ` : products.map(p => `
              <div class="glass-card rounded-3xl overflow-hidden border border-white hover:scale-[1.01] transition-all flex flex-col justify-between group">
                <div class="relative">
                  <img src="${p.image}" class="w-full h-44 object-cover">
                  ${p.isOrganic ? `
                    <span class="absolute top-2 left-2 bg-emerald-500 text-white text-[9px] font-extrabold uppercase px-2.5 py-0.5 rounded-full">Organic</span>
                  ` : ''}
                  <span class="absolute bottom-2 right-2 bg-white/95 text-gray-800 text-[10px] font-extrabold px-2 py-0.5 rounded-lg shadow-sm border border-gray-100">Freshness: ${p.freshnessScore}%</span>
                </div>
                
                <div class="p-5 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h3 class="font-extrabold text-gray-800 text-base group-hover:text-emerald-700 transition">${p.cropName}</h3>
                    <p class="text-[10px] text-gray-400 mt-1 flex items-center gap-1">
                      <i data-lucide="user" class="w-3.5 h-3.5"></i> By ${p.farmerName}
                    </p>
                    <p class="text-[10px] text-gray-400 mt-0.5 flex items-center gap-1">
                      <i data-lucide="map-pin" class="w-3.5 h-3.5"></i> ${p.location}
                    </p>
                    <p class="text-xs text-gray-500 mt-3 line-clamp-2">${p.description || 'No description provided.'}</p>
                  </div>
                  
                  <div class="pt-4 border-t border-gray-50 flex items-center justify-between">
                    <div>
                      <span class="text-[9px] text-gray-400 font-bold block">PRICE</span>
                      <span class="text-base font-extrabold text-emerald-600">₹${p.price}/${p.unit || 'kg'}</span>
                      <span class="text-[9px] text-gray-400 block mt-0.5">Stock: ${p.quantity} ${p.unit || 'kg'}</span>
                    </div>
                    
                    ${!isFarmer ? `
                      <button data-id="${p.id}" class="btn-buy-product px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-1">
                        <span>Buy Now</span>
                      </button>
                    ` : `
                      <span class="text-xs font-bold text-gray-400">My Listing</span>
                    `}
                  </div>
                </div>
              </div>
            `).join('')}
          </div>

          <!-- Modals (Add Product / Buy Product) -->
          <div id="market-modal" class="hidden absolute inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
            <div class="glass-card w-full max-w-md p-6 rounded-2xl border border-white/60 space-y-4" id="market-modal-content">
              <!-- Content loaded dynamically -->
            </div>
          </div>
        </div>
      `;
    },

    init(appState, navigateTo) {
      const modal = document.getElementById('market-modal');
      const modalContent = document.getElementById('market-modal-content');

      // Add Product Click
      document.getElementById('btn-add-product')?.addEventListener('click', () => {
        let selectOptions = '';
        CROPS_DB.forEach(c => {
          selectOptions += `<option value="${c.name}">${c.name}</option>`;
        });

        modalContent.innerHTML = `
          <div class="flex justify-between items-center pb-2 border-b border-gray-100">
            <h4 class="font-extrabold text-gray-800 text-sm">List New Crop Harvest</h4>
            <button type="button" id="btn-close-market" class="text-gray-400 hover:text-gray-600"><i data-lucide="x" class="w-4 h-4"></i></button>
          </div>
          <form id="form-add-product" class="space-y-3 pt-2">
            <div>
              <label class="block text-[10px] font-bold text-gray-400 uppercase">Crop Category</label>
              <select id="m-name" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs bg-white">
                ${selectOptions}
              </select>
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="block text-[10px] font-bold text-gray-400 uppercase">Stock Quantity</label>
                <input type="number" id="m-qty" required placeholder="e.g. 500" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
              </div>
              <div>
                <label class="block text-[10px] font-bold text-gray-400 uppercase">Pricing (Per KG/Quintal)</label>
                <input type="number" id="m-price" required placeholder="₹ / Unit" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
              </div>
            </div>
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="block text-[10px] font-bold text-gray-400 uppercase">Organic Crop?</label>
                <select id="m-organic" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs bg-white">
                  <option value="true">Yes, 100% Organic</option>
                  <option value="false">No, Regular crop</option>
                </select>
              </div>
              <div>
                <label class="block text-[10px] font-bold text-gray-400 uppercase">Harvest Date</label>
                <input type="date" id="m-harvest" required class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
              </div>
            </div>
            <div>
              <label class="block text-[10px] font-bold text-gray-400 uppercase">Upload Image Url</label>
              <input type="text" id="m-image" placeholder="Image web link" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
            </div>
            <div>
              <label class="block text-[10px] font-bold text-gray-400 uppercase">Detailed Description</label>
              <textarea id="m-desc" placeholder="Details about seed type, soil fertilization..." class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs h-16"></textarea>
            </div>
            <button type="submit" class="w-full py-2.5 bg-green-600 hover:bg-green-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5">
              <i data-lucide="check-circle" class="w-4 h-4"></i>
              <span>List on Marketplace</span>
            </button>
          </form>
        `;

        modal.classList.remove('hidden');
        lucide.createIcons();
        document.getElementById('m-harvest').value = new Date().toISOString().split('T')[0];

        document.getElementById('btn-close-market').addEventListener('click', () => modal.classList.add('hidden'));

        document.getElementById('form-add-product').addEventListener('submit', (e) => {
          e.preventDefault();
          const cropName = document.getElementById('m-name').value;
          const quantity = parseFloat(document.getElementById('m-qty').value);
          const price = parseFloat(document.getElementById('m-price').value);
          const isOrganic = document.getElementById('m-organic').value === 'true';
          const harvestDate = document.getElementById('m-harvest').value;
          const image = document.getElementById('m-image').value || 'https://images.unsplash.com/photo-1595855759920-86582396756a?w=600';
          const description = document.getElementById('m-desc').value;

          LocalDB.addProduct({
            farmerId: appState.user.id,
            farmerName: appState.user.name,
            cropName,
            quantity,
            unit: "kg",
            price,
            isOrganic,
            harvestDate,
            image,
            description,
            location: `${appState.user.village || 'Anantapur'}, ${appState.user.district || 'AP'}`,
            freshnessScore: 100
          });

          window.app.showToast("Product listed for sale!", "success");
          modal.classList.add('hidden');
          navigateTo('marketplace');
        });
      });

      // Buy Product Click
      document.querySelectorAll('.btn-buy-product').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = e.currentTarget.getAttribute('data-id');
          const products = LocalDB.getProducts();
          const p = products.find(prod => prod.id === id);

          modalContent.innerHTML = `
            <div class="flex justify-between items-center pb-2 border-b border-gray-100">
              <h4 class="font-extrabold text-gray-800 text-sm">Direct Secure Checkout</h4>
              <button type="button" id="btn-close-market" class="text-gray-400 hover:text-gray-600"><i data-lucide="x" class="w-4 h-4"></i></button>
            </div>
            
            <div class="pt-2 flex gap-4">
              <img src="${p.image}" class="w-20 h-16 object-cover rounded-xl shrink-0">
              <div>
                <h5 class="font-bold text-xs text-gray-800">${p.cropName}</h5>
                <p class="text-[10px] text-gray-400 mt-1">Sold by: ${p.farmerName}</p>
                <p class="text-xs font-bold text-emerald-600 mt-0.5">₹${p.price}/${p.unit}</p>
              </div>
            </div>

            <form id="form-buy-product" class="space-y-3">
              <div>
                <label class="block text-[10px] font-bold text-gray-400 uppercase">Purchase Quantity (${p.unit})</label>
                <div class="flex gap-2">
                  <input type="number" id="buy-qty" value="10" min="1" max="${p.quantity}" required class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
                  <span class="text-xs self-center text-gray-400 font-bold">Max: ${p.quantity}</span>
                </div>
              </div>

              <!-- Price breakdown container -->
              <div class="p-3 bg-gray-50 border border-gray-100 rounded-xl space-y-1">
                <div class="flex justify-between text-xs text-gray-500">
                  <span>Product Total:</span>
                  <span id="buy-subtotal">₹${p.price * 10}</span>
                </div>
                <div class="flex justify-between text-xs text-gray-500">
                  <span>Direct Delivery Fee:</span>
                  <span class="text-green-600 font-bold">Free (Direct)</span>
                </div>
                <div class="flex justify-between text-sm font-extrabold text-gray-800 border-t border-gray-200/50 pt-1.5">
                  <span>Payable Amount:</span>
                  <span id="buy-grandtotal">₹${p.price * 10}</span>
                </div>
              </div>

              <!-- Payment Method selection -->
              <div>
                <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">Select Payment Mode</label>
                <div class="grid grid-cols-2 gap-2">
                  <label class="flex items-center gap-1.5 p-2 bg-white border border-green-500 rounded-xl text-xs cursor-pointer font-semibold text-gray-700">
                    <input type="radio" name="pay-mode" value="UPI" checked class="accent-green-600">
                    <span>UPI / Scan QR</span>
                  </label>
                  <label class="flex items-center gap-1.5 p-2 bg-white border border-gray-200 rounded-xl text-xs cursor-pointer font-semibold text-gray-700">
                    <input type="radio" name="pay-mode" value="COD" class="accent-green-600">
                    <span>Cash on Delivery</span>
                  </label>
                </div>
              </div>

              <button type="submit" class="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-1.5">
                <i data-lucide="shield-check" class="w-4 h-4"></i>
                <span>Verify & Pay Securely</span>
              </button>
            </form>
          `;

          modal.classList.remove('hidden');
          lucide.createIcons();

          const buyQty = document.getElementById('buy-qty');
          const subtotalEl = document.getElementById('buy-subtotal');
          const grandtotalEl = document.getElementById('buy-grandtotal');

          // Quantity change recalculation
          buyQty.addEventListener('input', () => {
            const qty = parseFloat(buyQty.value) || 0;
            const sub = qty * p.price;
            subtotalEl.innerText = `₹${sub.toLocaleString()}`;
            grandtotalEl.innerText = `₹${sub.toLocaleString()}`;
          });

          document.getElementById('btn-close-market').addEventListener('click', () => modal.classList.add('hidden'));

          // Submit buy transaction
          document.getElementById('form-buy-product').addEventListener('submit', (e) => {
            e.preventDefault();
            const quantity = parseFloat(buyQty.value);
            const mode = document.querySelector('input[name="pay-mode"]:checked').value;

            LocalDB.createOrder({
              customerId: appState.user.id,
              customerName: appState.user.name,
              productId: p.id,
              productName: p.cropName,
              quantity,
              price: p.price,
              total: quantity * p.price,
              status: "Processing",
              payment: `Paid (${mode})`
            });

            // Set state recipe suggestion key
            appState.lastPurchasedCrop = p.cropName;

            window.app.showToast("Order Placed Successfully!", "success");
            modal.classList.add('hidden');
            navigateTo('customer-dashboard');
          });
        });
      });
    }
  },

  // ==========================================
  // 11. CUSTOMER DASHBOARD MODULE
  // ==========================================
  CustomerDashboard: {
    render(appState) {
      const user = appState.user;
      const products = LocalDB.getProducts().slice(0, 3); // show top 3
      const orders = LocalDB.getOrders().filter(o => o.customerId === user.id);

      // Recipe generator check
      const recipeCrop = appState.lastPurchasedCrop || "Tomato";
      const recipe = GeminiService.generateRecipe(recipeCrop);

      return `
        <div class="space-y-6 page-fade-in">
          <!-- Welcome shell -->
          <div class="glass-card p-6 rounded-3xl border border-white/60 flex flex-col md:flex-row items-center justify-between gap-4">
            <div class="flex items-center gap-4">
              <img src="${user.photo || 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150'}" class="w-16 h-16 rounded-2xl object-cover border-2 border-emerald-500 shadow-md">
              <div>
                <h2 class="text-2xl font-bold text-gray-900">Good Day, ${user.name}!</h2>
                <p class="text-xs text-gray-400 mt-0.5 flex items-center gap-1"><i data-lucide="map-pin" class="w-3.5 h-3.5 text-emerald-600"></i> Delivery to: ${user.address || 'Bengaluru, Karnataka'}</p>
              </div>
            </div>
            <button id="btn-edit-cust" class="p-2 px-4 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 text-xs font-bold rounded-xl transition flex items-center gap-1">
              <i data-lucide="edit" class="w-3.5 h-3.5"></i> Edit Profile
            </button>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <!-- Left Pane: Marketplace Highlights & Orders -->
            <div class="lg:col-span-7 space-y-6">
              <!-- Today's deals -->
              <div class="glass-card p-6 rounded-3xl border border-white/60 space-y-4">
                <div class="flex justify-between items-center">
                  <h3 class="text-sm font-extrabold text-gray-700 uppercase tracking-wide">Featured Direct Harvests</h3>
                  <button id="btn-view-all-market" class="text-xs font-bold text-emerald-700 hover:text-emerald-800 transition">View All Marketplace</button>
                </div>

                <div class="space-y-3">
                  ${products.length === 0 ? `
                    <p class="text-center text-xs text-gray-400 py-4">No products listed.</p>
                  ` : products.map(p => `
                    <div class="flex items-center justify-between p-3 bg-white/50 border border-gray-100 rounded-2xl hover:scale-[1.005] transition-all">
                      <div class="flex items-center gap-3">
                        <img src="${p.image}" class="w-16 h-14 object-cover rounded-xl shadow-sm shrink-0">
                        <div>
                          <h4 class="text-xs font-bold text-gray-800">${p.cropName}</h4>
                          <p class="text-[10px] text-gray-400">By ${p.farmerName} | ${p.location}</p>
                          <span class="text-xs font-bold text-emerald-600 mt-1 block">₹${p.price}/${p.unit}</span>
                        </div>
                      </div>
                      <button data-id="${p.id}" class="btn-buy-dashboard px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-sm transition">
                        Buy
                      </button>
                    </div>
                  `).join('')}
                </div>
              </div>

              <!-- Order history -->
              <div class="glass-card p-6 rounded-3xl border border-white/60 space-y-4">
                <h3 class="text-sm font-extrabold text-gray-700 uppercase tracking-wide">My Orders</h3>
                <div class="space-y-2 max-h-[220px] overflow-y-auto no-scrollbar">
                  ${orders.length === 0 ? `
                    <p class="text-center text-xs text-gray-400 py-4">You have placed no orders yet.</p>
                  ` : orders.map(o => `
                    <div class="flex justify-between items-center p-3.5 bg-gray-50 border border-gray-100 rounded-xl">
                      <div>
                        <h4 class="text-xs font-bold text-gray-800">${o.productName} (x${o.quantity})</h4>
                        <p class="text-[10px] text-gray-400">${o.date} | Payment: ${o.payment}</p>
                      </div>
                      <div class="text-right">
                        <span class="text-xs font-bold text-gray-800 block">₹${o.total}</span>
                        <span class="px-2 py-0.5 bg-amber-100 text-amber-800 text-[9px] font-extrabold rounded-full">${o.status}</span>
                      </div>
                    </div>
                  `).reverse().join('')}
                </div>
              </div>
            </div>

            <!-- Right Pane: Recipe Generator advisory -->
            <div class="lg:col-span-5 space-y-6">
              <div class="glass-card p-6 rounded-3xl border-2 border-emerald-500 bg-gradient-to-br from-emerald-50/10 to-transparent relative overflow-hidden flex flex-col justify-between">
                <div class="absolute right-3 top-3 opacity-5 text-green-900">
                  <i data-lucide="chef-hat" class="w-36 h-36"></i>
                </div>
                
                <div class="relative z-10 space-y-4">
                  <div class="flex items-center gap-2">
                    <div class="p-2 bg-emerald-500/10 text-emerald-700 rounded-lg"><i data-lucide="chef-hat" class="w-5 h-5"></i></div>
                    <div>
                      <span class="text-[9px] text-emerald-700 font-extrabold uppercase tracking-wide block">AI Recipe Suggestion</span>
                      <h4 class="text-base font-extrabold text-gray-800 leading-tight">${recipe.name}</h4>
                    </div>
                  </div>

                  <p class="text-[10px] text-gray-400 font-bold uppercase">Nutrition Fact: <span class="text-xs font-semibold text-gray-600 normal-case block mt-0.5">${recipe.nutrition}</span></p>

                  <div class="space-y-1.5 pt-2 border-t border-gray-100">
                    <p class="text-xs font-bold text-gray-700">Ingredients needed:</p>
                    <ul class="text-[11px] text-gray-500 list-disc pl-4 space-y-0.5">
                      ${recipe.ingredients.map(i => `<li>${i}</li>`).join('')}
                    </ul>
                  </div>

                  <div class="space-y-1.5 pt-2 border-t border-gray-100">
                    <p class="text-xs font-bold text-gray-700">Preparation Steps:</p>
                    <ol class="text-[11px] text-gray-500 list-decimal pl-4 space-y-1">
                      ${recipe.steps.map(s => `<li>${s}</li>`).join('')}
                    </ol>
                  </div>
                </div>

                <div class="mt-6 pt-4 border-t border-gray-100/50 flex justify-between items-center relative z-10">
                  <span class="text-[10px] text-gray-400 font-bold">Prep time: ${recipe.duration}</span>
                  <button id="btn-next-recipe" class="px-3.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 text-xs font-bold rounded-xl transition">
                    Try Another Recipe
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      `;
    },

    init(appState, navigateTo) {
      document.getElementById('btn-edit-cust').addEventListener('click', () => navigateTo('profile'));
      document.getElementById('btn-view-all-market').addEventListener('click', () => navigateTo('marketplace'));

      // Dashboard item purchasing
      document.querySelectorAll('.btn-buy-dashboard').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const id = e.currentTarget.getAttribute('data-id');
          navigateTo('marketplace');
          // Simple delay triggers checkout popup
          setTimeout(() => {
            document.querySelector(`.btn-buy-product[data-id="${id}"]`)?.click();
          }, 300);
        });
      });

      // Next Recipe cycle simulation
      document.getElementById('btn-next-recipe').addEventListener('click', () => {
        const crops = ['Tomato', 'Chili', 'Spinach', 'Onion'];
        const current = appState.lastPurchasedCrop || 'Tomato';
        const nextIdx = (crops.indexOf(current) + 1) % crops.length;
        appState.lastPurchasedCrop = crops[nextIdx];
        window.app.showToast(`Loading recipe ideas for ${crops[nextIdx]}...`, "info");
        navigateTo('customer-dashboard');
      });
    }
  },

  // ==========================================
  // 12. ADMIN ANALYTICS DASHBOARD
  // ==========================================
  Admin: {
    render(appState) {
      const users = LocalDB.get(DB_KEYS.USERS) || [];
      const products = LocalDB.get(DB_KEYS.PRODUCTS) || [];
      const orders = LocalDB.get(DB_KEYS.ORDERS) || [];

      const farmersCount = users.filter(u => u.role === 'farmer').length;
      const customersCount = users.filter(u => u.role === 'customer').length;
      const totalSales = orders.reduce((sum, o) => sum + o.total, 0);

      return `
        <div class="space-y-6 page-fade-in">
          <h2 class="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <i data-lucide="shield-check" class="text-green-700 w-6 h-6"></i>
            KisanMithr Central Administration
          </h2>

          <!-- Stats Grid -->
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div class="glass-card p-5 rounded-2xl">
              <span class="text-[10px] text-gray-400 font-bold block uppercase mb-1">Total Farmers</span>
              <span class="text-2xl font-black text-gray-800">${farmersCount}</span>
            </div>
            <div class="glass-card p-5 rounded-2xl">
              <span class="text-[10px] text-gray-400 font-bold block uppercase mb-1">Registered Customers</span>
              <span class="text-2xl font-black text-gray-800">${customersCount}</span>
            </div>
            <div class="glass-card p-5 rounded-2xl">
              <span class="text-[10px] text-gray-400 font-bold block uppercase mb-1">Listed Products</span>
              <span class="text-2xl font-black text-gray-800">${products.length}</span>
            </div>
            <div class="glass-card p-5 rounded-2xl">
              <span class="text-[10px] text-emerald-700 font-bold block uppercase mb-1">Gross Sales Revenue</span>
              <span class="text-2xl font-black text-emerald-600">₹${totalSales.toLocaleString()}</span>
            </div>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <!-- Graph -->
            <div class="lg:col-span-7 glass-card p-6 rounded-3xl border border-white/60">
              <h3 class="text-sm font-bold text-gray-700 uppercase tracking-wide mb-4">Platform Growth Metrics</h3>
              <div class="relative h-64 bg-white/40 rounded-2xl p-4 border border-gray-100 flex items-center justify-center">
                <canvas id="chart-admin-growth"></canvas>
              </div>
            </div>

            <!-- Orders log -->
            <div class="lg:col-span-5 glass-card p-6 rounded-3xl border border-white/60">
              <h3 class="text-sm font-bold text-gray-700 uppercase tracking-wide mb-4">Recent Transactions</h3>
              <div class="space-y-2 max-h-[300px] overflow-y-auto no-scrollbar">
                ${orders.length === 0 ? `
                  <p class="text-center text-xs text-gray-400 py-4">No transactions logged.</p>
                ` : orders.map(o => `
                  <div class="flex justify-between items-center p-3 bg-white/50 border border-gray-100 rounded-xl text-xs">
                    <div>
                      <p class="font-bold text-gray-800">${o.productName}</p>
                      <p class="text-[10px] text-gray-400">Buyer: ${o.customerName}</p>
                    </div>
                    <div class="text-right">
                      <span class="font-bold text-gray-800">₹${o.total}</span>
                      <span class="px-2 py-0.5 bg-green-100 text-green-800 text-[9px] font-bold rounded-full block mt-0.5">${o.status}</span>
                    </div>
                  </div>
                `).reverse().join('')}
              </div>
            </div>
          </div>
        </div>
      `;
    },

    init(appState, navigateTo) {
      const ctx = document.getElementById('chart-admin-growth').getContext('2d');
      new Chart(ctx, {
        type: 'line',
        data: {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
          datasets: [
            {
              label: 'Farmers Registered',
              data: [5, 12, 28, 45, 62, 78],
              borderColor: '#10b981',
              tension: 0.3,
              fill: false
            },
            {
              label: 'Customers Registered',
              data: [15, 35, 78, 120, 190, 240],
              borderColor: '#3b82f6',
              tension: 0.3,
              fill: false
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { labels: { font: { size: 9 } } }
          },
          scales: {
            y: { grid: { color: 'rgba(0, 0, 0, 0.04)' } },
            x: { grid: { display: false } }
          }
        }
      });
    }
  },

  // ==========================================
  // 13. PROFILE & CONFIG SETTINGS MODULE
  // ==========================================
  Profile: {
    render(appState) {
      const user = appState.user;
      const isFarmer = user.role === 'farmer';

      return `
        <div class="max-w-xl mx-auto glass-card p-8 rounded-3xl border border-white/60 space-y-6 page-fade-in">
          <div class="text-center pb-4 border-b border-gray-100">
            <h2 class="text-2xl font-bold text-gray-900">Manage Profile Details</h2>
            <p class="text-xs text-gray-400 mt-1">Configure language, location, and account credentials</p>
          </div>

          <form id="form-profile-edit" class="space-y-4">
            <div class="flex flex-col items-center gap-2">
              <img src="${user.photo || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150'}" class="w-20 h-20 rounded-full border-2 border-green-500 object-cover shadow-sm">
              <label class="cursor-pointer text-xs font-bold text-green-700 hover:text-green-800 transition">
                <span>Upload Profile Photo</span>
                <input type="file" id="profile-photo-upload" class="hidden" accept="image/*">
              </label>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">Full Name</label>
                <input type="text" id="prof-name" required value="${user.name}" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
              </div>
              <div>
                <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">Mobile Number</label>
                <input type="tel" id="prof-phone" required value="${user.phone}" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs bg-gray-50 text-gray-500" readonly>
              </div>
            </div>

            <div>
              <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">Preferred Language</label>
              <select id="prof-lang" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs bg-white">
                ${LANGUAGES.map(l => `<option value="${l.code}" ${user.language === l.code ? 'selected' : ''}>${l.name}</option>`).join('')}
              </select>
            </div>

            ${isFarmer ? `
              <div class="space-y-3 pt-3 border-t border-gray-100">
                <h4 class="text-xs font-bold text-green-700">Farm Configurations</h4>
                <div class="grid grid-cols-2 gap-2">
                  <div>
                    <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">Land Size (Acres)</label>
                    <input type="number" id="prof-land" value="${user.landArea || 1}" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs">
                  </div>
                  <div>
                    <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">Soil Type</label>
                    <select id="prof-soil" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs bg-white">
                      <option value="Black Soil" ${user.soilType === 'Black Soil' ? 'selected' : ''}>Black Soil</option>
                      <option value="Loamy" ${user.soilType === 'Loamy' ? 'selected' : ''}>Loamy Soil</option>
                      <option value="Clayey" ${user.soilType === 'Clayey' ? 'selected' : ''}>Clayey Soil</option>
                      <option value="Sandy Loam" ${user.soilType === 'Sandy Loam' ? 'selected' : ''}>Sandy Loam</option>
                    </select>
                  </div>
                </div>
                <div class="grid grid-cols-3 gap-2">
                  <div>
                    <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">Village</label>
                    <input type="text" id="prof-village" value="${user.village || ''}" class="block w-full px-2 py-1.5 border border-gray-200 rounded-xl text-xs">
                  </div>
                  <div>
                    <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">District</label>
                    <input type="text" id="prof-district" value="${user.district || ''}" class="block w-full px-2 py-1.5 border border-gray-200 rounded-xl text-xs">
                  </div>
                  <div>
                    <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">PIN Code</label>
                    <input type="text" id="prof-pin" value="${user.pinCode || ''}" class="block w-full px-2 py-1.5 border border-gray-200 rounded-xl text-xs">
                  </div>
                </div>
              </div>
            ` : `
              <div>
                <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">Delivery Address</label>
                <textarea id="prof-address" class="block w-full px-3 py-2 border border-gray-200 rounded-xl text-xs h-16">${user.address || ''}</textarea>
              </div>
            `}

            <div class="flex gap-2 pt-4 border-t border-gray-100">
              <button type="button" id="btn-prof-logout" class="flex-1 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs rounded-xl transition">
                Logout Session
              </button>
              <button type="submit" class="flex-1 py-2.5 bg-green-600 hover:bg-green-700 text-white font-bold text-xs rounded-xl shadow-md transition">
                Save Configurations
              </button>
            </div>
          </form>
        </div>
      `;
    },

    init(appState, navigateTo) {
      const form = document.getElementById('form-profile-edit');
      const photoUpload = document.getElementById('profile-photo-upload');
      const logoutBtn = document.getElementById('btn-prof-logout');

      let uploadedPhotoUrl = appState.user.photo;

      photoUpload.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            uploadedPhotoUrl = event.target.result;
            document.querySelector('#form-profile-edit img').src = uploadedPhotoUrl;
            window.app.showToast("Profile image loaded!", "success");
          };
          reader.readAsDataURL(file);
        }
      });

      logoutBtn.addEventListener('click', () => {
        LocalDB.clearSession();
        appState.user = null;
        window.app.showToast("Logged out successfully.", "info");
        navigateTo('auth');
      });

      form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const name = document.getElementById('prof-name').value.trim();
        const language = document.getElementById('prof-lang').value;

        let fields = { name, language, photo: uploadedPhotoUrl };

        if (appState.user.role === 'farmer') {
          const landArea = document.getElementById('prof-land').value;
          const soilType = document.getElementById('prof-soil').value;
          const village = document.getElementById('prof-village').value.trim();
          const district = document.getElementById('prof-district').value.trim();
          const pinCode = document.getElementById('prof-pin').value.trim();

          fields = { ...fields, landArea, soilType, village, district, pinCode };
        } else {
          const address = document.getElementById('prof-address').value.trim();
          fields = { ...fields, address };
        }

        const updated = LocalDB.updateUser(appState.user.id, fields);
        appState.user = updated;
        window.app.showToast("Profile updated successfully!", "success");
        
        navigateTo(updated.role === 'farmer' ? 'farmer-dashboard' : (updated.role === 'admin' ? 'admin' : 'customer-dashboard'));
      });
    }
  }
};
