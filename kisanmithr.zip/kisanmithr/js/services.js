// KisanMithr LocalStorage Database and AI Services

import { CROPS_DB, SCHEMES_DB, DISEASES_DB, MARKET_TRENDS_DB } from './data.js';

// ==========================================
// 1. LOCAL STORAGE DATABASE (LOCALDB)
// ==========================================

const DB_KEYS = {
  USERS: 'km_users',
  PRODUCTS: 'km_products',
  ORDERS: 'km_orders',
  EXPENSES: 'km_expenses',
  SESSION: 'km_session_user'
};

const DEFAULT_USERS = [
  {
    id: "farmer_1",
    name: "Ramanna Reddy",
    phone: "9876543210",
    email: "ramanna@kisanmithr.org",
    role: "farmer",
    language: "te",
    photo: "https://images.unsplash.com/photo-1542838132-92c53300491e?w=150&auto=format&fit=crop&q=60",
    village: "Ragulapadu",
    district: "Anantapur",
    state: "Andhra Pradesh",
    pinCode: "515411",
    aadhaarNumber: "1234 5678 9012",
    farmLocation: "14.6819° N, 77.6006° E",
    landArea: "4.5",
    soilType: "Black Soil",
    currentCrop: "cotton",
    budget: "40000",
    createdAt: "2026-01-15T12:00:00.000Z"
  },
  {
    id: "customer_1",
    name: "Deepika Sharma",
    phone: "8765432109",
    email: "deepika@gmail.com",
    role: "customer",
    language: "en",
    photo: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=60",
    address: "Apt 4B, Green Meadows, Bengaluru, Karnataka",
    createdAt: "2026-02-10T12:00:00.000Z"
  },
  {
    id: "admin_1",
    name: "KisanMithr Admin",
    phone: "9999999999",
    email: "admin@kisanmithr.gov.in",
    role: "admin",
    language: "en",
    photo: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=60",
    createdAt: "2026-01-01T12:00:00.000Z"
  }
];

const DEFAULT_PRODUCTS = [
  {
    id: "p1",
    farmerId: "farmer_1",
    farmerName: "Ramanna Reddy",
    cropName: "Organic Cotton Staples",
    quantity: 800, // kg
    unit: "kg",
    price: 90, // per kg
    image: "https://images.unsplash.com/photo-1594489428504-5c0c480a15fd?w=600&auto=format&fit=crop&q=60",
    location: "Ragulapadu, Anantapur",
    harvestDate: "2026-06-15",
    isOrganic: true,
    description: "Premium long-staple organic cotton harvested with sustainable methods. Free of chemical pest control.",
    freshnessScore: 92
  },
  {
    id: "p2",
    farmerId: "farmer_1",
    farmerName: "Ramanna Reddy",
    cropName: "Fresh Red Chilies",
    quantity: 150,
    unit: "kg",
    price: 180,
    image: "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?w=600&auto=format&fit=crop&q=60",
    location: "Ragulapadu, Anantapur",
    harvestDate: "2026-06-18",
    isOrganic: false,
    description: "High spice Teja variety red chili, freshly sun-dried and sorted.",
    freshnessScore: 98
  }
];

const DEFAULT_EXPENSES = [
  { id: "e1", farmerId: "farmer_1", cropId: "cotton", category: "Seeds", amount: 3200, date: "2026-05-10", notes: "Bt Cotton seeds purchase" },
  { id: "e2", farmerId: "farmer_1", cropId: "cotton", category: "Fertilizer", amount: 4000, date: "2026-05-18", notes: "Urea and NPK compost" },
  { id: "e3", farmerId: "farmer_1", cropId: "cotton", category: "Labour", amount: 6500, date: "2026-06-01", notes: "Sowing and weeding wages" },
  { id: "e4", farmerId: "farmer_1", cropId: "cotton", category: "Pesticides", amount: 2800, date: "2026-06-10", notes: "Organic neem pesticide spray" }
];

const DEFAULT_ORDERS = [
  {
    id: "o1",
    customerId: "customer_1",
    customerName: "Deepika Sharma",
    productId: "p2",
    productName: "Fresh Red Chilies",
    quantity: 10,
    price: 180,
    total: 1800,
    status: "Delivered",
    payment: "Paid (UPI)",
    date: "2026-06-19"
  }
];

export const LocalDB = {
  init() {
    if (!localStorage.getItem(DB_KEYS.USERS)) {
      localStorage.setItem(DB_KEYS.USERS, JSON.stringify(DEFAULT_USERS));
    }
    if (!localStorage.getItem(DB_KEYS.PRODUCTS)) {
      localStorage.setItem(DB_KEYS.PRODUCTS, JSON.stringify(DEFAULT_PRODUCTS));
    }
    if (!localStorage.getItem(DB_KEYS.EXPENSES)) {
      localStorage.setItem(DB_KEYS.EXPENSES, JSON.stringify(DEFAULT_EXPENSES));
    }
    if (!localStorage.getItem(DB_KEYS.ORDERS)) {
      localStorage.setItem(DB_KEYS.ORDERS, JSON.stringify(DEFAULT_ORDERS));
    }
  },

  get(key) {
    this.init();
    return JSON.parse(localStorage.getItem(key)) || [];
  },

  save(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
  },

  // Auth Operations
  registerUser(userData) {
    const users = this.get(DB_KEYS.USERS);
    const id = 'user_' + Math.random().toString(36).substr(2, 9);
    const newUser = { id, createdAt: new Date().toISOString(), ...userData };
    users.push(newUser);
    this.save(DB_KEYS.USERS, users);
    this.setSession(newUser);
    return newUser;
  },

  loginUser(phoneOrEmail, role) {
    const users = this.get(DB_KEYS.USERS);
    const user = users.find(u => (u.phone === phoneOrEmail || u.email === phoneOrEmail) && u.role === role);
    if (user) {
      this.setSession(user);
      return user;
    }
    return null;
  },

  updateUser(userId, updatedFields) {
    const users = this.get(DB_KEYS.USERS);
    const idx = users.findIndex(u => u.id === userId);
    if (idx !== -1) {
      users[idx] = { ...users[idx], ...updatedFields };
      this.save(DB_KEYS.USERS, users);
      // Update session if it's the current user
      const currentUser = this.getSession();
      if (currentUser && currentUser.id === userId) {
        this.setSession(users[idx]);
      }
      return users[idx];
    }
    return null;
  },

  getSession() {
    return JSON.parse(localStorage.getItem(DB_KEYS.SESSION)) || null;
  },

  setSession(user) {
    localStorage.setItem(DB_KEYS.SESSION, JSON.stringify(user));
  },

  clearSession() {
    localStorage.removeItem(DB_KEYS.SESSION);
  },

  // Product Operations
  getProducts() {
    return this.get(DB_KEYS.PRODUCTS);
  },

  addProduct(productData) {
    const products = this.get(DB_KEYS.PRODUCTS);
    const id = 'prod_' + Math.random().toString(36).substr(2, 9);
    const newProduct = { id, ...productData };
    products.push(newProduct);
    this.save(DB_KEYS.PRODUCTS, products);
    return newProduct;
  },

  // Expense Operations
  getExpenses(farmerId) {
    const expenses = this.get(DB_KEYS.EXPENSES);
    return expenses.filter(e => e.farmerId === farmerId);
  },

  addExpense(expenseData) {
    const expenses = this.get(DB_KEYS.EXPENSES);
    const id = 'exp_' + Math.random().toString(36).substr(2, 9);
    const newExpense = { id, ...expenseData };
    expenses.push(newExpense);
    this.save(DB_KEYS.EXPENSES, expenses);
    return newExpense;
  },

  deleteExpense(expenseId) {
    const expenses = this.get(DB_KEYS.EXPENSES);
    const updated = expenses.filter(e => e.id !== expenseId);
    this.save(DB_KEYS.EXPENSES, updated);
  },

  // Order Operations
  getOrders() {
    return this.get(DB_KEYS.ORDERS);
  },

  createOrder(orderData) {
    const orders = this.get(DB_KEYS.ORDERS);
    const id = 'ord_' + Math.random().toString(36).substr(2, 9);
    const newOrder = { id, date: new Date().toISOString().split('T')[0], ...orderData };
    orders.push(newOrder);
    
    // Deduct stock quantity in products
    const products = this.get(DB_KEYS.PRODUCTS);
    const pIdx = products.findIndex(p => p.id === orderData.productId);
    if (pIdx !== -1) {
      products[pIdx].quantity = Math.max(0, products[pIdx].quantity - orderData.quantity);
      this.save(DB_KEYS.PRODUCTS, products);
    }
    
    this.save(DB_KEYS.ORDERS, orders);
    return newOrder;
  },

  updateOrderStatus(orderId, status) {
    const orders = this.get(DB_KEYS.ORDERS);
    const idx = orders.findIndex(o => o.id === orderId);
    if (idx !== -1) {
      orders[idx].status = status;
      this.save(DB_KEYS.ORDERS, orders);
      return orders[idx];
    }
    return null;
  }
};

// Initialize DB immediately
LocalDB.init();

// ==========================================
// 2. WEATHER SERVICE
// ==========================================

export const WeatherService = {
  getWeather(location) {
    // Generate high-fidelity mock weather data matching the current date
    const hours = new Date().getHours();
    const temp = hours > 18 || hours < 6 ? 26 : 33;
    
    return {
      temp,
      humidity: 62,
      rainfall: "12mm forecast today",
      rainProbability: "85%",
      windSpeed: "14 km/h East",
      alerts: [
        { severity: "warning", message: "Moderate rain expected at 4:00 PM. Take care of harvested crops." }
      ],
      risks: {
        heatwave: "Low",
        flood: "Low",
        drought: "Moderate (Seasonal dry spells)"
      },
      advice: [
        "Delay pesticide application due to evening showers forecast.",
        "Ensure drainage channels in paddy fields are clear.",
        "Optimal temperature for cotton bolls opening."
      ]
    };
  }
};

// ==========================================
// 3. GEMINI AI SERVICE
// ==========================================

const LOCAL_BOT_RESPONSES = {
  en: {
    hello: "Hello! I am KisanMithr, your AI farming assistant. How can I help you today with crops, weather, diseases, or market prices?",
    crop_wheat: "Wheat requires sandy loam or clayey loam soils. Best sown in Oct-Nov and harvested in Mar-Apr. Moderate water is needed (4-6 irrigations). Key fertilizers: Urea and NPK.",
    crop_cotton: "Cotton grows best in deep black soil. Best sown in May-June. Sowing needs 3-4 irrigations; later stages require drip or rain. Watch out for Bollworm and Leaf Curl virus.",
    crop_rice: "Rice (Paddy) needs clayey soil that retains water. Best sown in June-July (Kharif). Keep standing water (5-10cm) during growth. Protect from blast disease.",
    fertilizer: "General tip: Apply N:P:K fertilizers in ratios of 4:2:1 for cereal crops. Test your soil first to avoid over-fertilizing and save costs.",
    disease_advice: "If you observe leaf spots or yellowing, upload a photo in the 'Disease Detection' section for instant visual analysis and cures.",
    fallback: "I understand you are asking about farming. Can you clarify if it's about crop cultivation, weather risk, fertilizer, pest control, or selling your harvest on our marketplace?"
  },
  te: {
    hello: "నమస్తే! నేను కిసాన్ మిత్ర AI సహాయకుడిని. ఈరోజు పంటలు, వాతావరణం లేదా తెగుళ్ల గురించి మీకు ఎలా సహాయం చేయగలను?",
    crop_wheat: "గోధుమ పంటకు లోమీ లేదా నల్ల రేగడి నేలలు అనుకూలం. అక్టోబర్-నవంబర్‌లో విత్తుకోవాలి. 4-6 తడులు అవసరం.",
    crop_cotton: "పత్తి పంటకు లోతైన నల్ల రేగడి నేలలు చాలా మంచివి. మే-జూన్‌లో విత్తుకోవాలి. గులాబీ రంగు పురుగు, ఆకు ముడుత తెగులు పట్ల జాగ్రత్త వహించండి.",
    crop_rice: "వరి పంటకు నీరు నిల్వ ఉండే జిగురు బంకమట్టి నేలలు కావాలి. జూన్-జూలై అనుకూలం. బ్లాస్ట్ (అగ్గి తెగులు) నుండి రక్షించుకోవాలి.",
    fertilizer: "ఎరువుల సలహా: సాధారణంగా వరి/గోధుమ పంటలకు 4:2:1 నిష్పత్తిలో N:P:K వాడాలి. ఖర్చు తగ్గించుకోవడానికి ముందుగా భూసార పరీక్ష చేయించండి.",
    disease_advice: "ఆకులపై మచ్చలు కనిపిస్తే, తక్షణ విశ్లేషణ కోసం 'తెగుళ్ల గుర్తింపు' విభాగంలో ఫోటో అప్‌లోడ్ చేయండి.",
    fallback: "వ్యవసాయం గురించి అడుగుతున్నందుకు ధన్యవాదాలు. మీకు ఏ పంట, విత్తనాలు లేదా ఎరువుల గురించి సమాచారం కావాలో తెలియజేయండి."
  },
  hi: {
    hello: "नमस्ते! मैं किसानमित्र AI कृषि सहायक हूँ। आज मैं फसलों, मौसम, कीट नियंत्रण या मंडी भाव के बारे में आपकी क्या मदद कर सकता हूँ?",
    crop_wheat: "गेहूं के लिए दोमट मिट्टी सबसे अच्छी है। अक्टूबर-नवंबर में बुवाई और मार्च-अप्रैल में कटाई होती है। 4-6 सिंचाइयों की आवश्यकता होती है।",
    crop_cotton: "कपास के लिए काली मिट्टी सर्वोत्तम है। मई-जून में बुवाई करें। जल निकास अच्छा होना चाहिए।",
    crop_rice: "धान के लिए चिकनी मिट्टी की आवश्यकता होती है। जून-जुलाई में बुवाई करें। खेत में पानी जमा रहना आवश्यक है।",
    fertilizer: "उर्वरक: अनाज की फसलों के लिए N:P:K का सामान्य अनुपात 4:2:1 रखें। लागत बचाने के लिए मिट्टी की जांच अवश्य करवाएं।",
    fallback: "कृषि सहायता में आपका स्वागत है। कृपया अपनी समस्या स्पष्ट करें ताकि मैं सटीक सलाह दे सकूँ।"
  }
};

export const GeminiService = {
  getApiKey() {
    return localStorage.getItem('km_gemini_key') || '';
  },

  setApiKey(key) {
    localStorage.setItem('km_gemini_key', key);
  },

  async askAI(message, langCode = 'en') {
    const apiKey = this.getApiKey();
    
    if (apiKey) {
      try {
        // Real Gemini API integration
        const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
        const systemPrompt = `You are KisanMithr, an expert AI agricultural assistant. Answer the farmer's question in a professional, empathetic, and clear manner, specifically tailored to the language code: "${langCode}". Keep answers action-oriented, providing organic solutions, chemical dosages where applicable, and cost-saving tips.`;
        
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  { text: `${systemPrompt}\n\nUser Question: ${message}` }
                ]
              }
            ]
          })
        });
        
        const data = await response.json();
        if (data.candidates && data.candidates[0].content.parts[0].text) {
          return data.candidates[0].content.parts[0].text;
        } else {
          console.error("Gemini response error", data);
          throw new Error("Invalid response format");
        }
      } catch (err) {
        console.warn("Real Gemini API request failed. Falling back to local smart engine.", err);
        // Fall through to mock engine
      }
    }
    
    // Smart local response simulator
    return new Promise((resolve) => {
      setTimeout(() => {
        const text = message.toLowerCase();
        const pool = LOCAL_BOT_RESPONSES[langCode] || LOCAL_BOT_RESPONSES['en'];
        
        if (text.includes("hello") || text.includes("hi") || text.includes("namaste") || text.includes("నమస్తే")) {
          resolve(pool.hello);
        } else if (text.includes("wheat") || text.includes("గోధుమ") || text.includes("गेहूं")) {
          resolve(pool.crop_wheat);
        } else if (text.includes("cotton") || text.includes("పత్తి") || text.includes("कपास")) {
          resolve(pool.crop_cotton);
        } else if (text.includes("rice") || text.includes("paddy") || text.includes("వరి") || text.includes("धान")) {
          resolve(pool.crop_rice);
        } else if (text.includes("fertilizer") || text.includes("fertiliser") || text.includes("ఎరువులు") || text.includes("खाद")) {
          resolve(pool.fertilizer);
        } else if (text.includes("disease") || text.includes("pest") || text.includes("తెగులు") || text.includes("బీमारी")) {
          resolve(pool.disease_advice);
        } else {
          resolve(pool.fallback);
        }
      }, 800);
    });
  },

  // Generates crop recommendations based on farmer profile inputs
  recommendCrops(inputs) {
    // Rank crops based on soil compatibility and irrigation method
    const matchingCrops = CROPS_DB.map(crop => {
      let score = 50; // baseline
      
      // Match soil
      const soilMatch = crop.soilTypes.some(s => s.toLowerCase().includes(inputs.soilType.toLowerCase()));
      if (soilMatch) score += 30;
      
      // Match season
      const seasonMatch = crop.seasons.some(s => s.toLowerCase().includes(inputs.season.toLowerCase()));
      if (seasonMatch) score += 15;
      
      // Match irrigation
      if (inputs.irrigationMethod.includes("Drip") && crop.irrigationMethod.includes("Drip")) {
        score += 15;
      } else if (inputs.irrigationMethod.includes("Flood") && crop.irrigationMethod.includes("Flood")) {
        score += 10;
      }
      
      // Budget check
      const landSize = parseFloat(inputs.landArea) || 1;
      const totalCost = crop.investmentPerAcre * landSize;
      const budget = parseFloat(inputs.budget) || 100000;
      if (totalCost > budget) {
        score -= 20; // penalize if over budget
      } else {
        score += 10;
      }

      return {
        ...crop,
        matchScore: Math.min(98, Math.max(45, score)),
        // Calculate dynamic costings for farmer's land size
        totalInvestment: crop.investmentPerAcre * landSize,
        expectedRevenue: crop.expectedRevenuePerAcre * landSize,
        netProfit: crop.profitPerAcre * landSize,
      };
    });

    // Sort by match score descending
    matchingCrops.sort((a, b) => b.matchScore - a.matchScore);
    
    // First crop is the "Best Recommendation"
    return matchingCrops;
  },

  // Predicts profits using full list of specific crop inputs
  predictProfit(inputs) {
    const landSize = parseFloat(inputs.landSize) || 1;
    const seed = parseFloat(inputs.seedCost) || 0;
    const fertilizer = parseFloat(inputs.fertilizerCost) || 0;
    const labour = parseFloat(inputs.labourCost) || 0;
    const transport = parseFloat(inputs.transportCost) || 0;
    const pesticides = parseFloat(inputs.pesticideCost) || 0;

    const totalInvestment = seed + fertilizer + labour + transport + pesticides;
    
    // Find typical crop details
    const cropMeta = CROPS_DB.find(c => c.id === inputs.cropId) || CROPS_DB[0];
    
    // Yield calculation based on typical yield and inputs (e.g. fertilizer spending)
    const fertilizerFactor = Math.min(1.2, Math.max(0.8, fertilizer / (cropMeta.avgFertilizerCostPerAcre * landSize)));
    const yieldEstimation = cropMeta.typicalYieldPerAcre * landSize * fertilizerFactor;
    
    const expectedRevenue = yieldEstimation * cropMeta.mandiPricePerQuintal;
    const netProfit = expectedRevenue - totalInvestment;
    const roi = totalInvestment > 0 ? (netProfit / totalInvestment) * 100 : 0;
    
    return {
      totalInvestment,
      expectedRevenue: Math.round(expectedRevenue),
      netProfit: Math.round(netProfit),
      roi: Math.round(roi),
      yieldEstimation: parseFloat(yieldEstimation.toFixed(1)),
      confidenceScore: totalInvestment > 0 ? 88 : 45
    };
  },

  // Generates smart recipes based on purchased product
  generateRecipe(cropName) {
    const recipes = {
      "chili": {
        name: "Andhra Spicy Chili Pickle (Avakaya Style)",
        duration: "30 mins",
        nutrition: "Rich in Vitamin C, high capsaicin content (boosts metabolism)",
        ingredients: [
          "Fresh Red Chilies - 250g",
          "Mustard Seeds Powder - 50g",
          "Salt - 40g",
          "Sesame Oil - 100ml",
          "Tamarind Paste - 30g"
        ],
        steps: [
          "Wash and thoroughly dry the red chilies (moisture ruins pickles).",
          "Slit the chilies or cut them into bite-sized pieces.",
          "In a bowl, mix mustard powder, salt, and tamarind paste.",
          "Heat sesame oil, let it cool slightly, then toss the chilies and spice mix together.",
          "Store in a clean glass jar. Tastes best after curing for 3 days."
        ]
      },
      "tomato": {
        name: "Fresh Farmhouse Tomato Chutney",
        duration: "15 mins",
        nutrition: "Lycopene rich, low calorie, high hydration",
        ingredients: [
          "Ripened Red Tomatoes - 4 large",
          "Green Chilies - 2",
          "Garlic Cloves - 4",
          "Mustard & Cumin seeds - 1 tsp",
          "Curry leaves & oil - 1 tbsp"
        ],
        steps: [
          "Roughly chop the tomatoes and garlic.",
          "Sauté green chilies and garlic in oil, then add tomatoes and salt.",
          "Cook until tomatoes are completely soft and mushy.",
          "Blend into a coarse paste after cooling.",
          "Temper with hot oil, mustard seeds, cumin seeds, and curry leaves."
        ]
      }
    };

    // Fallback general recipe
    const fallback = {
      name: "Organic Farm-to-Table Vegetable Stir-fry",
      duration: "20 mins",
      nutrition: "High fiber, rich in antioxidants and vital minerals",
      ingredients: [
        `${cropName} - 300g`,
        "Onion & Ginger paste - 1 tbsp",
        "Turmeric & Cumin - 1 tsp",
        "Cold-pressed oil - 1 tbsp",
        "Fresh coriander for garnish"
      ],
      steps: [
        "Clean and chop the produce into uniform bite-sized pieces.",
        "Heat oil in a pan, add cumin seeds, chopped onion, and ginger paste.",
        "Sauté until onions are translucent, then add turmeric.",
        "Add the chopped produce, sprinkle salt, cover and cook on medium heat for 10 minutes.",
        "Uncover, sauté on high heat for 2 minutes, garnish with fresh coriander and serve hot."
      ]
    };

    const key = Object.keys(recipes).find(k => cropName.toLowerCase().includes(k));
    return recipes[key] || fallback;
  }
};

// ==========================================
// 4. DISEASE DETECTION DEMO SERVICE
// ==========================================

export const DiseaseService = {
  detectDisease(fileName, cropName) {
    return new Promise((resolve) => {
      setTimeout(() => {
        // Matching rules based on file name or current crop selection
        const nameClean = (fileName + " " + cropName).toLowerCase();
        
        let match = null;
        if (nameClean.includes("tomato") || nameClean.includes("blight") || nameClean.includes("spot")) {
          match = DISEASES_DB.find(d => d.id === "tomato-late-blight");
        } else if (nameClean.includes("cotton") || nameClean.includes("curl") || nameClean.includes("whitefly")) {
          match = DISEASES_DB.find(d => d.id === "cotton-leaf-curl");
        } else if (nameClean.includes("rice") || nameClean.includes("blast") || nameClean.includes("paddy")) {
          match = DISEASES_DB.find(d => d.id === "rice-blast");
        } else if (nameClean.includes("wheat") || nameClean.includes("rust") || nameClean.includes("yellow")) {
          match = DISEASES_DB.find(d => d.id === "wheat-rust");
        } else {
          // Default selection if unknown
          match = {
            id: "unknown-pest",
            crop: cropName || "Crop",
            name: "Mildew / Insect Infestation (Slight)",
            confidence: "78%",
            cause: "Environmental dampness coupled with sucking insects (thrips/aphids).",
            symptoms: "Minor yellow speckles on the upper leaf surface and sticky honeydew residues.",
            treatment: "Isolate affected plants, spray soap oil emulsion, and regulate watering.",
            organicSolution: "Spray garlic-chili extract mixed with soap water (5ml/L) in early morning.",
            chemicalSolution: "Apply mild neem-based bio-pesticides or Dimethoate (1.5ml/L) if spreading fast.",
            preventionMethods: "Maintain spacing to allow sun exposure, avoid waterlogging, clear weeds."
          };
        }
        resolve(match);
      }, 2000); // 2-second scan delay
    });
  }
};
