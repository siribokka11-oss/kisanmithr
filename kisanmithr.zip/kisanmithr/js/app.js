// KisanMithr SPA Core App Entry & Router
import { LocalDB } from './services.js';
import { Components } from './components.js';

// Global application state
const AppState = {
  user: null,
  currentView: 'auth',
  lastPurchasedCrop: null, // tracked to update recipes dynamically
  darkMode: false
};

// Main DOM containers
const appContainer = document.getElementById('app');
const toastContainer = document.getElementById('toast-container');
const splashScreen = document.getElementById('splash-screen');

// Toast notifications engine
const showToast = (message, type = 'success') => {
  const toastId = 'toast-' + Math.random().toString(36).substr(2, 9);
  const bgClass = type === 'success' ? 'bg-green-600' : (type === 'error' ? 'bg-red-600' : 'bg-blue-600');
  const iconName = type === 'success' ? 'check-circle' : (type === 'error' ? 'alert-circle' : 'info');
  
  const toastHTML = `
    <div id="${toastId}" class="flex items-center gap-2.5 px-4 py-3 text-white rounded-2xl shadow-xl transition-all duration-300 transform translate-y-2 opacity-0 ${bgClass}">
      <i data-lucide="${iconName}" class="w-4 h-4 shrink-0"></i>
      <span class="text-xs font-bold">${message}</span>
    </div>
  `;
  
  toastContainer.insertAdjacentHTML('beforeend', toastHTML);
  lucide.createIcons();
  
  const el = document.getElementById(toastId);
  // Animate in
  setTimeout(() => {
    el.classList.remove('translate-y-2', 'opacity-0');
  }, 50);

  // Animate out and remove
  setTimeout(() => {
    el.classList.add('translate-y-2', 'opacity-0');
    setTimeout(() => el.remove(), 300);
  }, 4000);
};

// Make toast public for components
window.app = { showToast };

// Core Navigation shell renderer
const renderNavigation = () => {
  if (!AppState.user || AppState.currentView === 'auth') {
    return ''; // No navigation on login/register pages
  }

  const role = AppState.user.role;
  const view = AppState.currentView;

  // Custom nav buttons depending on User Role
  let navItems = [];
  if (role === 'farmer') {
    navItems = [
      { id: 'farmer-dashboard', label: 'Home', icon: 'home' },
      { id: 'crop-recommendation', label: 'AI Crop Match', icon: 'sparkles' },
      { id: 'marketplace', label: 'Marketplace', icon: 'shopping-bag' },
      { id: 'expenses', label: 'Expenses', icon: 'trending-up' },
      { id: 'assistant', label: 'AI Assistant', icon: 'bot' },
      { id: 'schemes', label: 'Schemes', icon: 'landmark' },
      { id: 'profile', label: 'Profile', icon: 'user' }
    ];
  } else if (role === 'customer') {
    navItems = [
      { id: 'customer-dashboard', label: 'Home', icon: 'home' },
      { id: 'marketplace', label: 'Shop Harvests', icon: 'shopping-bag' },
      { id: 'assistant', label: 'AI Assistant', icon: 'bot' },
      { id: 'profile', label: 'Profile', icon: 'user' }
    ];
  } else if (role === 'admin') {
    navItems = [
      { id: 'admin', label: 'Admin Panel', icon: 'shield-check' },
      { id: 'marketplace', label: 'Products', icon: 'shopping-bag' },
      { id: 'schemes', label: 'Manage Schemes', icon: 'landmark' },
      { id: 'profile', label: 'Profile', icon: 'user' }
    ];
  }

  return `
    <header class="sticky top-0 z-40 bg-white/70 backdrop-blur-md border-b border-gray-100 px-4 py-3 flex items-center justify-between">
      <div class="flex items-center gap-2 cursor-pointer" id="brand-logo-nav">
        <div class="p-2 bg-green-600 text-white rounded-xl">
          <i data-lucide="sprout" class="w-5 h-5"></i>
        </div>
        <h1 class="text-lg font-black text-gray-900 tracking-tight">KisanMithr</h1>
      </div>

      <!-- Desktop Nav -->
      <nav class="hidden lg:flex items-center gap-1.5">
        ${navItems.map(item => `
          <button data-target="${item.id}" class="nav-trigger-btn px-3 py-2 text-xs font-bold rounded-xl transition flex items-center gap-1.5 ${
            view === item.id 
              ? 'bg-green-500/10 text-green-700' 
              : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
          }">
            <i data-lucide="${item.icon}" class="w-4 h-4"></i>
            <span>${item.label}</span>
          </button>
        `).join('')}
      </nav>

      <!-- Action items -->
      <div class="flex items-center gap-2">
        <button id="btn-toggle-dark" class="p-2 bg-gray-50 hover:bg-gray-100 text-gray-500 rounded-xl transition" title="Toggle Theme">
          <i data-lucide="${AppState.darkMode ? 'sun' : 'moon'}" class="w-4.5 h-4.5"></i>
        </button>
        <span class="text-xs text-gray-400 font-bold px-2 py-1 bg-gray-100 rounded-lg capitalize hidden sm:inline-block">${role} Portal</span>
      </div>
    </header>

    <!-- Mobile Nav Bar (Bottom Navigation) -->
    <nav class="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-gray-100 px-2 py-2 flex justify-around items-center shadow-lg pb-safe">
      ${navItems.map(item => `
        <button data-target="${item.id}" class="nav-trigger-btn flex flex-col items-center gap-1 p-2 text-gray-400 rounded-xl transition min-w-[50px] ${
          view === item.id ? 'text-green-700 font-bold' : ''
        }">
          <i data-lucide="${item.icon}" class="w-5 h-5 ${view === item.id ? 'scale-110 text-green-600' : ''}"></i>
          <span class="text-[9px]">${item.label}</span>
        </button>
      `).join('')}
    </nav>
  `;
};

// Navigate to view wrapper
const navigateTo = (viewName) => {
  AppState.currentView = viewName;
  renderApp();
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

// Render Main App layout
const renderApp = () => {
  const headerNavHTML = renderNavigation();
  
  // Resolve component matching view name
  let componentName = '';
  if (AppState.currentView === 'auth') componentName = 'Auth';
  else if (AppState.currentView === 'farmer-dashboard') componentName = 'FarmerDashboard';
  else if (AppState.currentView === 'crop-recommendation') componentName = 'CropRecommendation';
  else if (AppState.currentView === 'profit-calculator') componentName = 'ProfitCalculator';
  else if (AppState.currentView === 'disease-detection') componentName = 'DiseaseDetection';
  else if (AppState.currentView === 'expenses') componentName = 'Expenses';
  else if (AppState.currentView === 'assistant') componentName = 'Assistant';
  else if (AppState.currentView === 'schemes') componentName = 'Schemes';
  else if (AppState.currentView === 'marketplace') componentName = 'Marketplace';
  else if (AppState.currentView === 'customer-dashboard') componentName = 'CustomerDashboard';
  else if (AppState.currentView === 'admin') componentName = 'Admin';
  else if (AppState.currentView === 'profile') componentName = 'Profile';

  const component = Components[componentName];
  if (!component) {
    appContainer.innerHTML = `<div class="p-8 text-center text-rose-500">View "${AppState.currentView}" not found.</div>`;
    return;
  }

  const mainContentHTML = component.render(AppState);

  appContainer.innerHTML = `
    ${headerNavHTML}
    <main class="max-w-7xl mx-auto px-4 py-6 pb-24 lg:pb-8">
      ${mainContentHTML}
    </main>
  `;

  // Initialize interactive elements from lucide icons and component setup
  lucide.createIcons();

  // Attach navigation triggers
  document.querySelectorAll('.nav-trigger-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const target = e.currentTarget.getAttribute('data-target');
      navigateTo(target);
    });
  });

  // Logo home navigation
  document.getElementById('brand-logo-nav')?.addEventListener('click', () => {
    if (AppState.user) {
      const homeView = AppState.user.role === 'farmer' 
        ? 'farmer-dashboard' 
        : (AppState.user.role === 'admin' ? 'admin' : 'customer-dashboard');
      navigateTo(homeView);
    }
  });

  // Theme Toggler
  document.getElementById('btn-toggle-dark')?.addEventListener('click', () => {
    AppState.darkMode = !AppState.darkMode;
    const body = document.body;
    if (AppState.darkMode) {
      body.classList.add('dark');
      // Simple dark color mock
      body.style.backgroundColor = '#121814';
      body.style.color = '#e2e8f0';
    } else {
      body.classList.remove('dark');
      body.style.backgroundColor = '#f7f9f6';
      body.style.color = '#1b2e1e';
    }
    navigateTo(AppState.currentView); // Refresh layout
    showToast(`Dark mode ${AppState.darkMode ? 'activated' : 'deactivated'}`, "info");
  });

  // Call component-specific JS listeners
  component.init(AppState, navigateTo);
};

// Initial App Bootstrapper
const initApp = () => {
  // Splash Screen animation delay
  setTimeout(() => {
    splashScreen.classList.add('opacity-0', 'pointer-events-none');
    
    // Check if session user is already logged in
    const cachedUser = LocalDB.getSession();
    if (cachedUser) {
      AppState.user = cachedUser;
      const initialView = cachedUser.role === 'farmer' 
        ? 'farmer-dashboard' 
        : (cachedUser.role === 'admin' ? 'admin' : 'customer-dashboard');
      navigateTo(initialView);
    } else {
      navigateTo('auth');
    }
  }, 2200); // 2.2 seconds show splash loader
};

// Kickoff
initApp();
export { navigateTo, AppState };
