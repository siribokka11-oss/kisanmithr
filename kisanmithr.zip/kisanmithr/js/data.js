// KisanMithr Predefined Lookup Databases

export const CROPS_DB = [
  {
    id: "rice",
    name: "Rice (Paddy)",
    category: "Grain",
    image: "https://images.unsplash.com/photo-1536882240095-0379873feb4e?w=600&auto=format&fit=crop&q=60",
    soilTypes: ["Clayey", "Loamy"],
    seasons: ["Kharif"],
    growthDuration: "120-150 days",
    waterRequirement: "High (Standing water)",
    avgSeedCostPerAcre: 1500,
    avgFertilizerCostPerAcre: 3500,
    avgLabourCostPerAcre: 6000,
    avgTransportCostPerAcre: 1200,
    avgPesticideCostPerAcre: 1800,
    typicalYieldPerAcre: 22, // in quintals
    mandiPricePerQuintal: 2183, // MSP 2023-24
    riskScore: "Medium",
    demandScore: 90,
    sustainabilityScore: 70,
    investmentPerAcre: 14000,
    expectedRevenuePerAcre: 48026,
    profitPerAcre: 34026,
    roi: 243,
    bestTime: "June - July",
    irrigationMethod: "Flood Irrigation"
  },
  {
    id: "wheat",
    name: "Wheat",
    category: "Grain",
    image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=600&auto=format&fit=crop&q=60",
    soilTypes: ["Loamy", "Clayey Loam"],
    seasons: ["Rabi"],
    growthDuration: "110-140 days",
    waterRequirement: "Moderate",
    avgSeedCostPerAcre: 2000,
    avgFertilizerCostPerAcre: 3000,
    avgLabourCostPerAcre: 4000,
    avgTransportCostPerAcre: 1000,
    avgPesticideCostPerAcre: 1000,
    typicalYieldPerAcre: 18,
    mandiPricePerQuintal: 2275, // MSP
    riskScore: "Low",
    demandScore: 95,
    sustainabilityScore: 85,
    investmentPerAcre: 11000,
    expectedRevenuePerAcre: 40950,
    profitPerAcre: 29950,
    roi: 272,
    bestTime: "October - November",
    irrigationMethod: "Sprinkler / Canal"
  },
  {
    id: "cotton",
    name: "Cotton",
    category: "Fiber",
    image: "https://images.unsplash.com/photo-1594489428504-5c0c480a15fd?w=600&auto=format&fit=crop&q=60",
    soilTypes: ["Black Soil", "Alluvial Soil"],
    seasons: ["Kharif"],
    growthDuration: "150-180 days",
    waterRequirement: "Moderate",
    avgSeedCostPerAcre: 3200,
    avgFertilizerCostPerAcre: 4000,
    avgLabourCostPerAcre: 7500,
    avgTransportCostPerAcre: 1500,
    avgPesticideCostPerAcre: 3800,
    typicalYieldPerAcre: 8,
    mandiPricePerQuintal: 6620, // MSP long staple
    riskScore: "High",
    demandScore: 85,
    sustainabilityScore: 60,
    investmentPerAcre: 20000,
    expectedRevenuePerAcre: 52960,
    profitPerAcre: 32960,
    roi: 165,
    bestTime: "May - June",
    irrigationMethod: "Drip Irrigation"
  },
  {
    id: "tomato",
    name: "Tomato",
    category: "Vegetable",
    image: "https://images.unsplash.com/photo-1595855759920-86582396756a?w=600&auto=format&fit=crop&q=60",
    soilTypes: ["Sandy Loam", "Loamy"],
    seasons: ["Kharif", "Rabi", "Zaid"],
    growthDuration: "90-110 days",
    waterRequirement: "Moderate",
    avgSeedCostPerAcre: 5000,
    avgFertilizerCostPerAcre: 6000,
    avgLabourCostPerAcre: 10000,
    avgTransportCostPerAcre: 3000,
    avgPesticideCostPerAcre: 4000,
    typicalYieldPerAcre: 150, // quintals
    mandiPricePerQuintal: 800, // highly variable
    riskScore: "High",
    demandScore: 88,
    sustainabilityScore: 80,
    investmentPerAcre: 28000,
    expectedRevenuePerAcre: 120000,
    profitPerAcre: 92000,
    roi: 328,
    bestTime: "October (Rabi) / June (Kharif)",
    irrigationMethod: "Drip Irrigation"
  },
  {
    id: "chili",
    name: "Red Chili",
    category: "Spice",
    image: "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?w=600&auto=format&fit=crop&q=60",
    soilTypes: ["Loamy", "Black Soil"],
    seasons: ["Kharif", "Rabi"],
    growthDuration: "150-170 days",
    waterRequirement: "Low to Moderate",
    avgSeedCostPerAcre: 4000,
    avgFertilizerCostPerAcre: 5500,
    avgLabourCostPerAcre: 9000,
    avgTransportCostPerAcre: 2000,
    avgPesticideCostPerAcre: 4500,
    typicalYieldPerAcre: 15,
    mandiPricePerQuintal: 12000,
    riskScore: "Medium",
    demandScore: 92,
    sustainabilityScore: 78,
    investmentPerAcre: 25000,
    expectedRevenuePerAcre: 180000,
    profitPerAcre: 155000,
    roi: 620,
    bestTime: "July - August",
    irrigationMethod: "Drip / Sprinkler"
  },
  {
    id: "maize",
    name: "Maize (Corn)",
    category: "Grain",
    image: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=600&auto=format&fit=crop&q=60",
    soilTypes: ["Loamy Sand", "Clayey Loam"],
    seasons: ["Kharif", "Rabi"],
    growthDuration: "90-120 days",
    waterRequirement: "Low to Moderate",
    avgSeedCostPerAcre: 2200,
    avgFertilizerCostPerAcre: 3500,
    avgLabourCostPerAcre: 4500,
    avgTransportCostPerAcre: 1200,
    avgPesticideCostPerAcre: 1200,
    typicalYieldPerAcre: 20,
    mandiPricePerQuintal: 2090, // MSP
    riskScore: "Low",
    demandScore: 87,
    sustainabilityScore: 82,
    investmentPerAcre: 12600,
    expectedRevenuePerAcre: 41800,
    profitPerAcre: 29200,
    roi: 231,
    bestTime: "June (Kharif) / Oct (Rabi)",
    irrigationMethod: "Furrow / Sprinkler"
  }
];

export const SCHEMES_DB = [
  {
    id: "pm-kisan",
    name: "PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)",
    category: "Financial Support",
    eligibility: "All small and marginal landholding farmer families who hold cultivable land in their names.",
    benefits: "Direct income support of ₹6,000 per year in three equal installments of ₹2,000 directly into bank accounts.",
    documents: "Aadhaar Card, Land Holding Papers, Bank Account Details, Mobile Number.",
    link: "https://pmkisan.gov.in/"
  },
  {
    id: "crop-insurance",
    name: "PMFBY (Pradhan Mantri Fasal Bima Yojana)",
    category: "Insurance",
    eligibility: "All farmers growing notified crops in notified areas, including sharecroppers and tenant farmers.",
    benefits: "Comprehensive insurance coverage against crop failure due to natural calamities, pests, and diseases. Farmers pay a low premium (1.5% to 2% for food crops, 5% for commercial crops).",
    documents: "Land records, Sowing Certificate, Bank Passbook, Aadhaar Card.",
    link: "https://pmfby.gov.in/"
  },
  {
    id: "solar-pump-subsidy",
    name: "PM-KUSUM (Solar Pump Subsidy Scheme)",
    category: "Subsidy",
    eligibility: "Individual farmers, groups of farmers, cooperatives, Panchayats, Water User Associations.",
    benefits: "Up to 60% subsidy on solar pump installations to replace diesel agricultural pumps, providing day-time reliable power.",
    documents: "Aadhaar Card, Land ownership proof, Bank account details, Electricity connection certificate.",
    link: "https://pmkusum.mnre.gov.in/"
  },
  {
    id: "agri-loans",
    name: "KCC (Kisan Credit Card Scheme)",
    category: "Credit / Loan",
    eligibility: "All farmers, owner-cultivators, tenant farmers, and self-help groups.",
    benefits: "Provides short-term credit loans up to ₹3 Lakhs at very low interest rates (around 4% after timely repayment incentives). Also includes accidental insurance cover.",
    documents: "Aadhaar Card, Land possession certificate, Passport size photo, Bank verification.",
    link: "https://www.sbi.co.in/web/personal-banking/loans/agriculture-banking/kisan-credit-card"
  }
];

export const DISEASES_DB = [
  {
    id: "tomato-late-blight",
    crop: "Tomato",
    name: "Late Blight (Phytophthora infestans)",
    confidence: "94%",
    cause: "A fungal-like water mold disease that thrives in cool, wet, humid conditions.",
    symptoms: "Water-soaked dark lesions on leaves, white fuzzy growth on undersides in humid weather, and firm brown decay on tomato fruits.",
    treatment: "Immediately prune infected foliage, apply fungicides, and ensure spacing for proper air flow.",
    organicSolution: "Spray copper fungicides, apply neem oil regularly, and use compost tea to strengthen plant immunity.",
    chemicalSolution: "Apply fungicides containing chlorothalonil, mancozeb, or metalaxyl as per dosage instructions.",
    preventionMethods: "Use resistant cultivars, use drip irrigation instead of overhead sprinklers to keep leaves dry, crop rotation."
  },
  {
    id: "cotton-leaf-curl",
    crop: "Cotton",
    name: "Cotton Leaf Curl Virus (CLCuV)",
    confidence: "91%",
    cause: "Gemini virus transmitted mainly by the sweetpotato whitefly (Bemisia tabaci).",
    symptoms: "Upward or downward curling of leaf margins, thickening of leaf veins, and forming leaf-like enations on undersides.",
    treatment: "Uproot and burn highly infested plants. Control the whitefly insect vector immediately.",
    organicSolution: "Spray soap water mixed with neem oil (1-2%), yellow sticky traps (10-15 traps per acre) to catch whiteflies.",
    chemicalSolution: "Apply systemic insecticides like imidacloprid or acetamiprid to control the whitefly populations.",
    preventionMethods: "Grow virus-resistant cotton varieties, keep fields weed-free, avoid continuous cropping of cotton."
  },
  {
    id: "rice-blast",
    crop: "Rice (Paddy)",
    name: "Rice Blast (Magnaporthe oryzae)",
    confidence: "96%",
    cause: "A devastating fungal disease that attacks leaves, collars, nodes, and panicles.",
    symptoms: "Spindle-shaped or eye-shaped lesions on leaves with gray centers and brown borders. Collapsed stems (neck blast) preventing grain filling.",
    treatment: "Avoid excessive nitrogen application. Spray fungicide at the boot and early panicle stages.",
    organicSolution: "Treat seeds with Trichoderma viride. Spray biological control agents like Pseudomonas fluorescens.",
    chemicalSolution: "Spray systemic fungicides containing Tricyclazole, Azoxystrobin, or Isoprothiolane.",
    preventionMethods: "Plant resistant varieties, maintain proper water levels, burn crop residue from previous seasons to eliminate spores."
  },
  {
    id: "wheat-rust",
    crop: "Wheat",
    name: "Yellow/Stripe Rust (Puccinia striiformis)",
    confidence: "93%",
    cause: "A wind-borne fungal pathogen that prefers cool temperatures (10-15°C) and high humidity.",
    symptoms: "Narrow yellow stripes composed of small powdery pustules (uredinia) running parallel along leaf veins.",
    treatment: "Apply foliar fungicides at the first sign of stripes to stop rapid spreading.",
    organicSolution: "Spray diluted sour buttermilk (fermented for 3-4 days) or baking soda mixed with liquid soap and water.",
    chemicalSolution: "Spray Triazole fungicides like Propiconazole or Tebuconazole immediately.",
    preventionMethods: "Sow rust-resistant varieties, practice early sowing to escape rust season, avoid high crop density."
  }
];

export const MARKET_TRENDS_DB = {
  years: ["Jan 26", "Feb 26", "Mar 26", "Apr 26", "May 26", "Jun 26"],
  crops: {
    rice: [1950, 2020, 2090, 2120, 2160, 2183],
    wheat: [2100, 2150, 2200, 2240, 2250, 2275],
    cotton: [6200, 6400, 6550, 6800, 6700, 6620],
    tomato: [600, 950, 1500, 2200, 1100, 800],
    chili: [10500, 11000, 11200, 11800, 12200, 12000],
    maize: [1850, 1920, 1950, 2010, 2050, 2090]
  },
  nearbyMandis: [
    { name: "Anantapur Rural Mandi", distance: "4 km", pricePremium: "+ ₹40/quintal" },
    { name: "Dharmavaram Town Market", distance: "12 km", pricePremium: "+ ₹120/quintal (Higher Demand)" },
    { name: "Hindupur Agriculture Yard", distance: "45 km", pricePremium: "+ ₹210/quintal (Best Buying Price)" }
  ]
};

export const LANGUAGES = [
  { code: "en", name: "English" },
  { code: "te", name: "తెలుగు (Telugu)" },
  { code: "hi", name: "हिन्दी (Hindi)" },
  { code: "ta", name: "தமிழ் (Tamil)" },
  { code: "kn", name: "ಕನ್ನಡ (Kannada)" }
];
